<?php
/**
 * HospiConnect - API services_list.php
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) jsonResponse(['error' => 'Non autorisé'], 401);

$db = getDB();
$services = $db->query('SELECT id, nom_service, code_prefixe FROM services WHERE actif=1 ORDER BY nom_service')->fetchAll();
jsonResponse(['services' => $services]);
