<?php
/**
 * HospiConnect - API ticket_action.php
 * Gère toutes les actions sur les tickets
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    jsonResponse(['error' => 'Non autorisé'], 401);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Méthode non autorisée'], 405);
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!verifyCsrfToken($input['csrf_token'] ?? '')) {
    jsonResponse(['error' => 'Token CSRF invalide'], 403);
}

$action   = $input['action']   ?? '';
$ticketId = (int)($input['ticket_id'] ?? 0);
$db       = getDB();
$user     = currentUser();

// ─── Appeler le suivant (médecin) ─────────────────────────────────────────────
if ($action === 'appeler_suivant') {
    $serviceId = (int)($input['service_id'] ?? $user['service_id'] ?? 0);
    if (!$serviceId) jsonResponse(['error' => 'Service non défini'], 400);

    $stmt = $db->prepare("
        SELECT t.id, t.numero_ticket, t.niveau_priorite, t.motif_visite, t.salle_appelee,
               p.nom, p.prenom
        FROM tickets t
        JOIN patients p ON p.id = t.patient_id
        WHERE t.service_id=? AND t.statut_ticket='en_attente' AND DATE(t.cree_le)=CURDATE()
        ORDER BY FIELD(t.niveau_priorite,'urgence','prioritaire','standard'), t.cree_le ASC
        LIMIT 1
    ");
    $stmt->execute([$serviceId]);
    $ticket = $stmt->fetch();

    if (!$ticket) jsonResponse(['error' => 'Aucun patient en attente'], 404);

    // Récup salle par défaut du service
    $stmtSvc = $db->prepare('SELECT salle_defaut FROM services WHERE id=?');
    $stmtSvc->execute([$serviceId]);
    $svc = $stmtSvc->fetch();
    $salle = $ticket['salle_appelee'] ?: ($svc['salle_defaut'] ?? 'Accueil');

    $db->prepare("UPDATE tickets SET statut_ticket='appele', appele_le=NOW(), salle_appelee=?, medecin_id=? WHERE id=?")
       ->execute([$salle, $user['id'], $ticket['id']]);

    auditLog('APPEL_TICKET', $ticket['id'], 'tickets', ['numero' => $ticket['numero_ticket']]);

    jsonResponse([
        'success'   => true,
        'ticket_id' => $ticket['id'],
        'numero'    => $ticket['numero_ticket'],
        'nom'       => $ticket['nom'] . ' ' . $ticket['prenom'],
        'motif'     => $ticket['motif_visite'] ?? '',
        'salle'     => $salle,
        'message'   => 'Ticket ' . $ticket['numero_ticket'] . ' appelé',
    ]);
}

// ─── Appeler un ticket spécifique ─────────────────────────────────────────────
if ($action === 'appeler') {
    if (!$ticketId) jsonResponse(['error' => 'Ticket ID manquant'], 400);

    $stmt = $db->prepare('SELECT * FROM tickets WHERE id=?');
    $stmt->execute([$ticketId]);
    $ticket = $stmt->fetch();
    if (!$ticket) jsonResponse(['error' => 'Ticket introuvable'], 404);

    $stmtSvc = $db->prepare('SELECT salle_defaut FROM services WHERE id=?');
    $stmtSvc->execute([$ticket['service_id']]);
    $svc   = $stmtSvc->fetch();
    $salle = $ticket['salle_appelee'] ?: ($svc['salle_defaut'] ?? 'Accueil');

    $db->prepare("UPDATE tickets SET statut_ticket='appele', appele_le=NOW(), salle_appelee=?, medecin_id=?, nb_rappels=nb_rappels+1 WHERE id=?")
       ->execute([$salle, $user['id'], $ticketId]);

    auditLog('APPEL_TICKET', $ticketId, 'tickets');
    jsonResponse(['success' => true, 'message' => 'Ticket appelé', 'salle' => $salle]);
}

// ─── Marquer absent ───────────────────────────────────────────────────────────
if ($action === 'absent') {
    if (!$ticketId) jsonResponse(['error' => 'Ticket ID manquant'], 400);

    $db->prepare("UPDATE tickets SET statut_ticket='absent', nb_rappels=nb_rappels+1 WHERE id=?")
       ->execute([$ticketId]);

    auditLog('TICKET_ABSENT', $ticketId, 'tickets');
    jsonResponse(['success' => true, 'message' => 'Patient marqué absent']);
}

// ─── Terminer / Clôturer ──────────────────────────────────────────────────────
if ($action === 'terminer') {
    if (!$ticketId) jsonResponse(['error' => 'Ticket ID manquant'], 400);

    $obs = trim($input['observation'] ?? '');
    $db->prepare("UPDATE tickets SET statut_ticket='termine', termine_le=NOW(), observation=? WHERE id=?")
       ->execute([$obs ?: null, $ticketId]);

    auditLog('TICKET_TERMINE', $ticketId, 'tickets');
    jsonResponse(['success' => true, 'message' => 'Consultation clôturée']);
}

// ─── Sauvegarder observation ──────────────────────────────────────────────────
if ($action === 'observation') {
    if (!$ticketId) jsonResponse(['error' => 'Ticket ID manquant'], 400);

    $obs = trim($input['observation'] ?? '');
    $db->prepare("UPDATE tickets SET observation=? WHERE id=?")
       ->execute([$obs, $ticketId]);

    auditLog('OBSERVATION_TICKET', $ticketId, 'tickets');
    jsonResponse(['success' => true, 'message' => 'Observation sauvegardée']);
}

// ─── Transfert inter-services ─────────────────────────────────────────────────
if ($action === 'transferer') {
    if (!$ticketId) jsonResponse(['error' => 'Ticket ID manquant'], 400);

    $newServiceId = (int)($input['service_id'] ?? 0);
    $motif        = trim($input['motif'] ?? '');
    if (!$newServiceId) jsonResponse(['error' => 'Service de destination manquant'], 400);

    // Récup ticket original
    $stmt = $db->prepare('SELECT * FROM tickets WHERE id=?');
    $stmt->execute([$ticketId]);
    $ticket = $stmt->fetch();
    if (!$ticket) jsonResponse(['error' => 'Ticket introuvable'], 404);

    // Vérif service différent
    if ($ticket['service_id'] === $newServiceId) {
        jsonResponse(['error' => 'Le service de destination est identique au service actuel'], 400);
    }

    try {
        $db->beginTransaction();

        // Clôturer le ticket actuel
        $db->prepare("UPDATE tickets SET statut_ticket='termine', termine_le=NOW() WHERE id=?")
           ->execute([$ticketId]);

        // Créer nouveau ticket dans le service cible
        $newNumero = generateTicketNumber($newServiceId);
        $db->prepare("
            INSERT INTO tickets (patient_id, service_id, secretaire_id, numero_ticket,
                                 niveau_priorite, motif_visite, statut_examen)
            VALUES (?,?,?,?,?,?,?)
        ")->execute([
            $ticket['patient_id'],
            $newServiceId,
            $user['id'],
            $newNumero,
            $ticket['niveau_priorite'],
            $motif ?: $ticket['motif_visite'],
            'aucun',
        ]);
        $newTicketId = $db->lastInsertId();

        $db->commit();

        auditLog('TRANSFERT_TICKET', $ticketId, 'tickets', [
            'nouveau_ticket_id' => $newTicketId,
            'service_destination' => $newServiceId,
            'nouveau_numero' => $newNumero,
        ]);

        jsonResponse([
            'success'        => true,
            'nouveau_ticket' => $newNumero,
            'nouveau_id'     => $newTicketId,
            'message'        => "Transféré → $newNumero",
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        jsonResponse(['error' => 'Erreur lors du transfert : ' . $e->getMessage()], 500);
    }
}

// ─── Marquer examens prêts + envoi email ──────────────────────────────────────
if ($action === 'examens_prets') {
    if (!$ticketId) jsonResponse(['error' => 'Ticket ID manquant'], 400);

    // Récup infos ticket + patient
    $stmt = $db->prepare("
        SELECT t.*, p.nom, p.prenom, p.email, t.cree_le as date_examen
        FROM tickets t
        JOIN patients p ON p.id = t.patient_id
        WHERE t.id=?
    ");
    $stmt->execute([$ticketId]);
    $ticket = $stmt->fetch();
    if (!$ticket) jsonResponse(['error' => 'Ticket introuvable'], 404);

    // Vérif pas déjà notifié
    if ($ticket['statut_examen'] === 'pret') {
        jsonResponse(['error' => 'Patient déjà notifié pour ces examens'], 400);
    }

    // Mettre à jour statut examen
    $db->prepare("UPDATE tickets SET statut_examen='pret' WHERE id=?")
       ->execute([$ticketId]);

    // Envoyer email
    $nomPrenom   = $ticket['prenom'] . ' ' . $ticket['nom'];
    $dateExamen  = date('d/m/Y', strtotime($ticket['date_examen']));
    $body        = emailTemplateExamens($nomPrenom, $dateExamen);
    $subject     = APP_ETABLISSEMENT . ' - Vos résultats d\'examens sont disponibles';
    $sent        = sendEmail($ticket['email'], $subject, $body, $ticketId, $ticket['patient_id'], 'examens_prets');

    auditLog('EXAMENS_PRETS', $ticketId, 'tickets', ['email_envoye' => $sent]);

    jsonResponse([
        'success' => true,
        'email_envoye' => $sent,
        'message' => $sent
            ? 'Email de notification envoyé à ' . $ticket['email']
            : 'Statut mis à jour (échec email)',
    ]);
}

// Action inconnue
jsonResponse(['error' => 'Action non reconnue : ' . $action], 400);
