<?php
/**
 * HospiConnect - API patient_search.php
 * Recherche patient en temps réel (auto-complétion)
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    jsonResponse(['error' => 'Non autorisé'], 401);
}

$q = trim($_GET['q'] ?? '');

if (strlen($q) < 3) {
    jsonResponse(['patients' => []]);
}

$db   = getDB();
$like = "%$q%";

$stmt = $db->prepare("
    SELECT id, ipp, nom, prenom, email, telephone,
           DATE_FORMAT(date_naissance, '%d/%m/%Y') as date_naissance
    FROM patients
    WHERE nom LIKE ? OR prenom LIKE ? OR ipp LIKE ? OR email LIKE ?
    ORDER BY nom, prenom
    LIMIT 10
");
$stmt->execute([$like, $like, $like, $like]);
$patients = $stmt->fetchAll();

jsonResponse(['patients' => $patients]);
