<?php
/**
 * HospiConnect - API kiosque.php
 * Données pour l'écran de salle d'attente (public, réseau interne)
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');
header('Cache-Control: no-cache');

$db = getDB();

// Dernier ticket appelé (toutes services confondus)
$stmtCurrent = $db->query("
    SELECT t.id, t.numero_ticket, t.salle_appelee, t.appele_le,
           p.nom, p.prenom, s.nom_service
    FROM tickets t
    JOIN patients p ON p.id = t.patient_id
    JOIN services s ON s.id = t.service_id
    WHERE t.statut_ticket IN ('appele','reappele')
      AND DATE(t.cree_le) = CURDATE()
    ORDER BY t.appele_le DESC
    LIMIT 1
");
$current = $stmtCurrent->fetch() ?: null;

// Historique des 7 derniers tickets appelés
$stmtHistory = $db->query("
    SELECT t.id, t.numero_ticket, t.salle_appelee, t.appele_le,
           s.nom_service
    FROM tickets t
    JOIN services s ON s.id = t.service_id
    WHERE t.statut_ticket IN ('appele','reappele','termine')
      AND t.appele_le IS NOT NULL
      AND DATE(t.cree_le) = CURDATE()
    ORDER BY t.appele_le DESC
    LIMIT 7
");
$history = $stmtHistory->fetchAll();

// Stats globales du moment
$stmtStats = $db->query("
    SELECT COUNT(*) as total_attente
    FROM tickets
    WHERE statut_ticket = 'en_attente'
      AND DATE(cree_le) = CURDATE()
");
$stats = $stmtStats->fetch();

jsonResponse([
    'current' => $current,
    'history' => $history,
    'stats'   => $stats,
    'ts'      => time(),
]);
