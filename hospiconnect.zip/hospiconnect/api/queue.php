<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');
header('Cache-Control: no-cache');

if (!isLoggedIn()) {
    echo json_encode(['tickets' => [], 'stats' => []]);
    exit;
}

$serviceId = (int)($_GET['service_id'] ?? 0);

if (!$serviceId) {
    echo json_encode(['tickets' => [], 'stats' => []]);
    exit;
}

$db = getDB();

$stmt = $db->prepare("
    SELECT t.id, t.numero_ticket, t.niveau_priorite, t.statut_ticket,
           t.motif_visite, t.cree_le, t.nb_rappels,
           p.nom, p.prenom,
           DATE_FORMAT(p.date_naissance, '%d/%m/%Y') as date_naissance,
           s.nom_service,
           TIMESTAMPDIFF(MINUTE, t.cree_le, NOW()) as wait_minutes
    FROM tickets t
    JOIN patients p ON p.id = t.patient_id
    JOIN services s ON s.id = t.service_id
    WHERE t.service_id = ?
      AND t.statut_ticket IN ('en_attente', 'appele', 'reappele')
      AND DATE(t.cree_le) = CURDATE()
    ORDER BY
      FIELD(t.niveau_priorite, 'urgence', 'prioritaire', 'standard'),
      t.cree_le ASC
");
$stmt->execute([$serviceId]);
$tickets = $stmt->fetchAll();

$stmtStats = $db->prepare("
    SELECT
      SUM(statut_ticket='en_attente') as en_attente,
      SUM(statut_ticket='appele')     as appeles,
      SUM(statut_ticket='termine')    as termines,
      SUM(statut_ticket='absent')     as absents
    FROM tickets
    WHERE service_id = ?
      AND DATE(cree_le) = CURDATE()
");
$stmtStats->execute([$serviceId]);
$stats = $stmtStats->fetch();

echo json_encode([
    'tickets' => $tickets,
    'stats'   => $stats ?? [],
    'ts'      => time(),
]);