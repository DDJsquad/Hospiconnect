login: admin



mot de passe admin: juniorDDJ@4410



**Correction login connexion**



**1.Ouvre phpMyAdmin ou ton client MySQL.**



Exécute :



SELECT id, login, password

FROM users;



Si tu vois quelque chose comme :

| login  | password  |

| ------ | --------- |

| admin  | admin     |

| doctor | doctor123 |



alors le problème est confirmé : les mots de passe sont stockés en clair alors que ton application attend des mots de passe hachés.



Étape 2 : Créer un générateur de hash



Dans le dossier de ton projet, crée un fichier :



generate\_hash.php



avec le contenu suivant :



<?php



echo password\_hash("admin", PASSWORD\_DEFAULT);



?>



Étape 3 : Exécuter le fichier



Dans ton navigateur :



http://localhost/hospiconnect/generate\_hash.php



Tu obtiendras quelque chose du genre :

$2y$10$X7P4y5k9vA6c....



Copie toute cette chaîne.



Étape 4 : Mettre à jour le compte admin



Dans MySQL :



UPDATE users

SET password='$2y$10$X7P4y5k9vA6c....'(Remplace par la valeur obtenue.)

WHERE login='admin';



Étape 5 : Tester la connexion



Utilise :

Login : admin

Mot de passe : admin











































