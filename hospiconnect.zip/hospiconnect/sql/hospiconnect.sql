-- ============================================================
-- HospiConnect - Clinique du Chatelet
-- Script SQL d'initialisation - v1.0
-- ============================================================

CREATE DATABASE IF NOT EXISTS hospiconnect
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE hospiconnect;

-- ─── 1. Services ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS services (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  nom_service   VARCHAR(100) NOT NULL,
  code_prefixe  VARCHAR(10)  NOT NULL UNIQUE,
  salle_defaut  VARCHAR(50)  DEFAULT NULL,
  actif         TINYINT(1)   NOT NULL DEFAULT 1,
  cree_le       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── 2. Utilisateurs ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  login               VARCHAR(50)  NOT NULL UNIQUE,
  password            VARCHAR(255) NOT NULL,
  role                ENUM('superadmin','admin','secretaire','medecin') NOT NULL,
  nom_complet         VARCHAR(150) NOT NULL DEFAULT '',
  email               VARCHAR(255) DEFAULT NULL,
  service_id          INT          DEFAULT NULL,
  actif               TINYINT(1)   NOT NULL DEFAULT 1,
  tentatives_echec    INT          NOT NULL DEFAULT 0,
  bloque_jusqu        DATETIME     DEFAULT NULL,
  reset_token         VARCHAR(64)  DEFAULT NULL,
  reset_token_expire  DATETIME     DEFAULT NULL,
  derniere_connexion  DATETIME     DEFAULT NULL,
  cree_le             TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── 3. Patients ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS patients (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  ipp             VARCHAR(50)  NOT NULL UNIQUE,
  nom             VARCHAR(100) NOT NULL,
  prenom          VARCHAR(100) NOT NULL,
  email           VARCHAR(255) NOT NULL,
  date_naissance  DATE         NOT NULL,
  telephone       VARCHAR(20)  DEFAULT NULL,
  cree_le         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  modifie_le      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── 4. Tickets ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tickets (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  patient_id       INT          NOT NULL,
  service_id       INT          NOT NULL,
  medecin_id       INT          DEFAULT NULL,
  secretaire_id    INT          DEFAULT NULL,
  numero_ticket    VARCHAR(20)  NOT NULL,
  salle_appelee    VARCHAR(50)  DEFAULT NULL,
  niveau_priorite  ENUM('standard','prioritaire','urgence') NOT NULL DEFAULT 'standard',
  statut_ticket    ENUM('en_attente','appele','reappele','absent','termine') NOT NULL DEFAULT 'en_attente',
  statut_examen    ENUM('aucun','en_cours','pret') NOT NULL DEFAULT 'aucun',
  motif_visite     VARCHAR(255) DEFAULT NULL,
  observation      TEXT         DEFAULT NULL,
  nb_rappels       INT          NOT NULL DEFAULT 0,
  cree_le          TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  appele_le        DATETIME     DEFAULT NULL,
  termine_le       DATETIME     DEFAULT NULL,
  FOREIGN KEY (patient_id)    REFERENCES patients(id) ON DELETE CASCADE,
  FOREIGN KEY (service_id)    REFERENCES services(id) ON DELETE CASCADE,
  FOREIGN KEY (medecin_id)    REFERENCES users(id)    ON DELETE SET NULL,
  FOREIGN KEY (secretaire_id) REFERENCES users(id)    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── 5. Email logs ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS email_logs (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id    INT          DEFAULT NULL,
  patient_id   INT          DEFAULT NULL,
  type_email   ENUM('arrivee','examens_prets','reinit_mdp','autre') NOT NULL,
  destinataire VARCHAR(255) NOT NULL,
  statut       ENUM('envoye','echec','retry') NOT NULL,
  tentatives   INT          NOT NULL DEFAULT 1,
  envoye_le    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ticket_id)  REFERENCES tickets(id)  ON DELETE SET NULL,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── 6. Audit logs ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_logs (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT          DEFAULT NULL,
  action       VARCHAR(100) NOT NULL,
  table_cible  VARCHAR(50)  DEFAULT NULL,
  entite_id    INT          DEFAULT NULL,
  details      JSON         DEFAULT NULL,
  ip_address   VARCHAR(45)  DEFAULT NULL,
  cree_le      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Index utiles ─────────────────────────────────────────────────────────────
CREATE INDEX idx_tickets_service_statut  ON tickets (service_id, statut_ticket);
CREATE INDEX idx_tickets_patient         ON tickets (patient_id);
CREATE INDEX idx_tickets_date            ON tickets (cree_le);
CREATE INDEX idx_audit_user              ON audit_logs (user_id);
CREATE INDEX idx_audit_action            ON audit_logs (action);
CREATE INDEX idx_patients_nom            ON patients (nom, prenom);
CREATE INDEX idx_patients_ipp            ON patients (ipp);

-- ─── Données initiales : Services ────────────────────────────────────────────
INSERT INTO services (nom_service, code_prefixe, salle_defaut) VALUES
  ('Consultation Générale', 'CON', 'Bureau 1'),
  ('Radiologie',            'RAD', 'Bureau 2'),
  ('Laboratoire',           'LAB', 'Bureau 3'),
  ('Pédiatrie',             'PED', 'Bureau 4'),
  ('Cardiologie',           'CAR', 'Bureau 5'),
  ('Urgences',              'URG', 'Salle Urgences');

-- ─── Données initiales : Utilisateurs ────────────────────────────────────────
-- Superadmin : login=admin / mdp=admin
INSERT INTO users (login, password, role, nom_complet, email) VALUES
  ('admin',
   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
   'superadmin',
   'Administrateur Système',
   NULL);

-- Secrétaire de démo : login=secretaire1 / mdp=password
INSERT INTO users (login, password, role, nom_complet, email, service_id) VALUES
  ('secretaire1',
   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
   'secretaire',
   'Marie Dupont',
   'marie.dupont@clinique-chatelet.fr',
   1);

-- Médecin de démo : login=dr.martin / mdp=password
INSERT INTO users (login, password, role, nom_complet, email, service_id) VALUES
  ('dr.martin',
   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
   'medecin',
   'Dr. Jean Martin',
   'jean.martin@clinique-chatelet.fr',
   1);

-- ─── Données de démo : Patients ──────────────────────────────────────────────
INSERT INTO patients (ipp, nom, prenom, email, date_naissance, telephone) VALUES
  ('CDCh-2025-00001', 'MBALLA',    'Emmanuel',  'emmanuel.mballa@email.com',   '1985-03-14', '+237 655 123 456'),
  ('CDCh-2025-00002', 'NKENG',     'Sophie',    'sophie.nkeng@email.com',      '1992-07-22', '+237 677 234 567'),
  ('CDCh-2025-00003', 'FOTSO',     'Pierre',    'pierre.fotso@email.com',      '1978-11-05', '+237 699 345 678'),
  ('CDCh-2025-00004', 'ATANGANA',  'Marie',     'marie.atangana@email.com',    '2001-02-18', '+237 651 456 789'),
  ('CDCh-2025-00005', 'BIYA',      'Christelle','christelle.biya@email.com',   '1968-09-30', NULL);

-- ─── NOTE : Le hash '$2y$10$92IXUNpkjO0rOQ5byMi...' correspond au mot de passe 'password'
-- Pour le superadmin, utilisez : admin/admin en production et changez immédiatement.
-- Pour régénérer un hash : php -r "echo password_hash('votre_mdp', PASSWORD_BCRYPT);"
