<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAuth(['admin','superadmin']);
$db = getDB();

// Période sélectionnée
$periode = $_GET['periode'] ?? 'jour';
// $dateSQL = match($periode) {
//     'semaine' => 'DATE(cree_le) >= CURDATE() - INTERVAL 7 DAY',
//     'mois'    => 'DATE(cree_le) >= CURDATE() - INTERVAL 30 DAY',
//     default   => 'DATE(cree_le) = CURDATE()',
// };

$dateSQL = match($periode) {
    'semaine' => 'DATE(t.cree_le) >= CURDATE() - INTERVAL 7 DAY',
    'mois'    => 'DATE(t.cree_le) >= CURDATE() - INTERVAL 30 DAY',
    default   => 'DATE(t.cree_le) = CURDATE()',
};

// Temps d'attente moyen par service
$attenteMoyenne = $db->query("
    SELECT s.nom_service, s.code_prefixe,
           COUNT(t.id) as total,
           AVG(TIMESTAMPDIFF(MINUTE, t.cree_le, IFNULL(t.appele_le, NOW()))) as attente_moy,
           SUM(t.statut_ticket='absent') as absents,
           SUM(t.statut_ticket='termine') as termines
    FROM services s
    LEFT JOIN tickets t ON t.service_id=s.id AND $dateSQL
    WHERE s.actif=1
    GROUP BY s.id
    ORDER BY attente_moy DESC
")->fetchAll();

// Affluence par heure (aujourd'hui seulement)
$affluence = $db->query("
    SELECT HOUR(cree_le) as heure, COUNT(*) as total
    FROM tickets
    WHERE DATE(cree_le) = CURDATE()
    GROUP BY HOUR(cree_le)
    ORDER BY heure
")->fetchAll();

// Patients les plus longs en attente (alertes)
$alertes = $db->query("
    SELECT t.numero_ticket, t.niveau_priorite, t.cree_le,
           TIMESTAMPDIFF(MINUTE, t.cree_le, NOW()) as wait,
           p.nom, p.prenom, s.nom_service
    FROM tickets t
    JOIN patients p ON p.id=t.patient_id
    JOIN services s ON s.id=t.service_id
    WHERE t.statut_ticket='en_attente'
      AND TIMESTAMPDIFF(MINUTE, t.cree_le, NOW()) >= " . WAIT_ALERT_MINUTES . "
    ORDER BY wait DESC
    LIMIT 20
")->fetchAll();

// Emails du jour
$emailStats = $db->query("
    SELECT type_email, statut, COUNT(*) as total
    FROM email_logs
    WHERE DATE(envoye_le) = CURDATE()
    GROUP BY type_email, statut
")->fetchAll();

// Transferts du jour
$transferts = $db->query("
    SELECT COUNT(*) as total FROM audit_logs
    WHERE action='TRANSFERT_TICKET' AND DATE(cree_le)=CURDATE()
")->fetchColumn();

// Données pour graphique affluence (JSON)
$heures = array_fill(0, 24, 0);
foreach ($affluence as $a) { $heures[(int)$a['heure']] = (int)$a['total']; }

$pageTitle = 'Statistiques';
require_once INCLUDES_PATH . '/header.php';
?>
<div class="d-flex align-items-center gap-2 mb-4 flex-wrap">
  <a href="<?= APP_URL ?>/modules/admin/dashboard.php" class="btn btn-sm btn-outline-secondary">
    <i class="bi bi-arrow-left"></i>
  </a>
  <h4 class="mb-0 fw-bold" style="color:var(--hc-blue-dark)">
    <i class="bi bi-bar-chart me-2"></i>Statistiques
  </h4>
  <div class="ms-auto btn-group">
    <?php foreach (['jour'=>'Aujourd\'hui','semaine'=>'7 jours','mois'=>'30 jours'] as $k=>$l): ?>
    <a href="?periode=<?= $k ?>" class="btn btn-sm <?= $periode===$k ? 'btn-primary' : 'btn-outline-primary' ?>"><?= $l ?></a>
    <?php endforeach; ?>
  </div>
  <a href="?periode=<?= $periode ?>&export=csv" class="btn btn-sm btn-outline-success">
    <i class="bi bi-download me-1"></i>Export CSV
  </a>
</div>

<?php
// Export CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="hospiconnect_stats_' . date('Y-m-d') . '.csv"');
    echo "\xEF\xBB\xBF"; // BOM UTF-8
    echo "Service;Total tickets;Attente moyenne (min);Terminés;Absents\n";
    foreach ($attenteMoyenne as $r) {
        echo sanitize($r['nom_service']) . ';' . $r['total'] . ';' . round($r['attente_moy'] ?? 0) . ';' . $r['termines'] . ';' . $r['absents'] . "\n";
    }
    exit;
}
?>

<!-- Alertes temps d'attente -->
<?php if (!empty($alertes)): ?>
<div class="alert alert-danger mb-3">
  <i class="bi bi-exclamation-triangle-fill me-2"></i>
  <strong><?= count($alertes) ?> patient(s) en attente depuis plus de <?= WAIT_ALERT_MINUTES ?> minutes !</strong>
</div>
<div class="hc-card mb-4">
  <div class="hc-card-header">
    <div class="icon" style="background:#fee2e2;color:#991b1b"><i class="bi bi-alarm"></i></div>
    <h5>Alertes — Attentes prolongées</h5>
  </div>
  <div class="table-responsive">
    <table class="table table-hc table-sm mb-0">
      <thead><tr><th>Ticket</th><th>Patient</th><th>Service</th><th>Priorité</th><th>Attente</th></tr></thead>
      <tbody>
        <?php foreach ($alertes as $a): ?>
        <tr>
          <td><span class="fw-bold text-danger"><?= sanitize($a['numero_ticket']) ?></span></td>
          <td><?= sanitize($a['nom']) ?> <?= sanitize($a['prenom']) ?></td>
          <td><?= sanitize($a['nom_service']) ?></td>
          <td><?= priorityBadge($a['niveau_priorite']) ?></td>
          <td><span class="wait-danger fw-bold"><i class="bi bi-clock me-1"></i><?= $a['wait'] ?> min</span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<div class="row g-3 mb-4">
  <!-- Graphique affluence -->
  <div class="col-lg-8">
    <div class="hc-card">
      <div class="hc-card-header">
        <div class="icon"><i class="bi bi-graph-up"></i></div>
        <h5>Affluence par heure — Aujourd'hui</h5>
      </div>
      <canvas id="chart-affluence" height="120"></canvas>
    </div>
  </div>

  <!-- Emails & Transferts -->
  <div class="col-lg-4">
    <div class="hc-card mb-3">
      <div class="hc-card-header">
        <div class="icon" style="background:#d1fae5;color:#065f46"><i class="bi bi-envelope-check"></i></div>
        <h5>Emails aujourd'hui</h5>
      </div>
      <?php
      $emailSent = 0; $emailFail = 0;
      foreach ($emailStats as $e) {
          if ($e['statut'] === 'envoye') $emailSent += $e['total'];
          else $emailFail += $e['total'];
      }
      ?>
      <div class="d-flex gap-3 text-center">
        <div class="flex-fill">
          <div class="fs-3 fw-bold text-success"><?= $emailSent ?></div>
          <small class="text-muted">Envoyés</small>
        </div>
        <div class="flex-fill">
          <div class="fs-3 fw-bold text-danger"><?= $emailFail ?></div>
          <small class="text-muted">Échoués</small>
        </div>
        <div class="flex-fill">
          <div class="fs-3 fw-bold text-primary"><?= $transferts ?></div>
          <small class="text-muted">Transferts</small>
        </div>
      </div>
    </div>

    <div class="hc-card">
      <div class="hc-card-header">
        <div class="icon"><i class="bi bi-pie-chart"></i></div>
        <h5>Taux résolution</h5>
      </div>
      <?php
      $totalAll  = array_sum(array_column($attenteMoyenne, 'total'));
      $totalTerm = array_sum(array_column($attenteMoyenne, 'termines'));
      $tauxRes   = $totalAll > 0 ? round($totalTerm / $totalAll * 100) : 0;
      ?>
      <div class="text-center">
        <div class="display-4 fw-bold text-<?= $tauxRes >= 70 ? 'success' : ($tauxRes >= 40 ? 'warning' : 'danger') ?>">
          <?= $tauxRes ?>%
        </div>
        <small class="text-muted">consultations terminées / total</small>
      </div>
    </div>
  </div>
</div>

<!-- Tableau par service -->
<div class="hc-card">
  <div class="hc-card-header">
    <div class="icon"><i class="bi bi-table"></i></div>
    <h5>Performances par service</h5>
  </div>
  <div class="table-responsive">
    <table class="table table-hc table-hover mb-0">
      <thead>
        <tr><th>Service</th><th>Total tickets</th><th>Attente moy.</th><th>Terminés</th><th>Absents</th><th>Taux résol.</th></tr>
      </thead>
      <tbody>
        <?php foreach ($attenteMoyenne as $r): ?>
        <tr>
          <td class="fw-semibold"><?= sanitize($r['nom_service']) ?> <code class="text-muted">(<?= sanitize($r['code_prefixe']) ?>)</code></td>
          <td><?= (int)$r['total'] ?></td>
          <td>
            <?php $moy = round($r['attente_moy'] ?? 0); ?>
            <span class="<?= $moy >= WAIT_ALERT_MINUTES ? 'wait-danger' : ($moy >= 20 ? 'wait-warn' : 'wait-ok') ?> fw-bold">
              <?= $moy ?> min
            </span>
          </td>
          <td><?= (int)$r['termines'] ?></td>
          <td><?= (int)$r['absents'] ?></td>
          <td>
            <?php $taux = $r['total'] > 0 ? round($r['termines'] / $r['total'] * 100) : 0; ?>
            <div class="progress" style="height:8px;min-width:80px">
              <div class="progress-bar bg-<?= $taux >= 70 ? 'success' : ($taux >= 40 ? 'warning' : 'danger') ?>"
                   style="width:<?= $taux ?>%"></div>
            </div>
            <small><?= $taux ?>%</small>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const ctx = document.getElementById('chart-affluence').getContext('2d');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: <?= json_encode(array_map(fn($h) => $h . 'h', range(0,23))) ?>,
    datasets: [{
      label: 'Patients enregistrés',
      data: <?= json_encode(array_values($heures)) ?>,
      backgroundColor: 'rgba(46,117,182,0.7)',
      borderColor: '#1A3A5C',
      borderWidth: 1,
      borderRadius: 4,
    }]
  },
  options: {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: {
      y: { beginAtZero: true, ticks: { stepSize: 1 } },
      x: { grid: { display: false } }
    }
  }
});
</script>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
