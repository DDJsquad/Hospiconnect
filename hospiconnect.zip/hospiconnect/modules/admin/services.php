<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAuth(['admin','superadmin']);
$db = getDB();
$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Erreur CSRF.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'create') {
            $nom     = trim($_POST['nom_service'] ?? '');
            $prefixe = strtoupper(trim($_POST['code_prefixe'] ?? ''));
            $salle   = trim($_POST['salle_defaut'] ?? '');
            if (strlen($nom) < 2 || strlen($prefixe) < 2) {
                $error = 'Nom (≥2 car.) et code préfixe (≥2 car.) requis.';
            } else {
                try {
                    $db->prepare("INSERT INTO services (nom_service,code_prefixe,salle_defaut) VALUES (?,?,?)")
                       ->execute([$nom, $prefixe, $salle ?: null]);
                    auditLog('CREATION_SERVICE', $db->lastInsertId(), 'services');
                    $success = "Service <strong>$nom</strong> créé.";
                } catch (PDOException $e) {
                    $error = strpos($e->getMessage(),'Duplicate') !== false
                        ? "Le code préfixe \"$prefixe\" existe déjà." : $e->getMessage();
                }
            }
        } elseif ($action === 'toggle') {
            $sid   = (int)$_POST['service_id'];
            $actif = (int)$_POST['actif'];
            $db->prepare('UPDATE services SET actif=? WHERE id=?')->execute([$actif, $sid]);
            auditLog('TOGGLE_SERVICE', $sid, 'services', ['actif'=>$actif]);
            $success = 'Service ' . ($actif ? 'activé' : 'désactivé') . '.';
        } elseif ($action === 'edit') {
            $sid   = (int)$_POST['service_id'];
            $nom   = trim($_POST['nom_service'] ?? '');
            $salle = trim($_POST['salle_defaut'] ?? '');
            if (strlen($nom) < 2) { $error = 'Nom requis.'; }
            else {
                $db->prepare("UPDATE services SET nom_service=?, salle_defaut=? WHERE id=?")
                   ->execute([$nom, $salle ?: null, $sid]);
                auditLog('MODIF_SERVICE', $sid, 'services');
                $success = 'Service mis à jour.';
            }
        }
    }
}

$services  = $db->query("
    SELECT s.*, COUNT(t.id) as nb_tickets_today
    FROM services s
    LEFT JOIN tickets t ON t.service_id=s.id AND DATE(t.cree_le)=CURDATE()
    GROUP BY s.id ORDER BY s.nom_service
")->fetchAll();

$csrfToken = generateCsrfToken();
$pageTitle = 'Gestion Services';
require_once INCLUDES_PATH . '/header.php';
?>
<div class="d-flex align-items-center gap-2 mb-4">
  <a href="<?= APP_URL ?>/modules/admin/dashboard.php" class="btn btn-sm btn-outline-secondary">
    <i class="bi bi-arrow-left"></i>
  </a>
  <h4 class="mb-0 fw-bold" style="color:var(--hc-blue-dark)">
    <i class="bi bi-hospital me-2"></i>Gestion des Services
  </h4>
  <button class="btn btn-hc-primary ms-auto" data-bs-toggle="modal" data-bs-target="#modal-new-service">
    <i class="bi bi-plus-circle me-1"></i>Nouveau service
  </button>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>

<div class="hc-card">
  <div class="table-responsive">
    <table class="table table-hc table-hover mb-0">
      <thead>
        <tr><th>Nom du service</th><th>Code préfixe</th><th>Salle/Bureau</th><th>Tickets aujourd'hui</th><th>Statut</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($services as $s): ?>
        <tr class="<?= !$s['actif'] ? 'opacity-50' : '' ?>">
          <td class="fw-semibold"><?= sanitize($s['nom_service']) ?></td>
          <td><code class="badge bg-secondary fs-6"><?= sanitize($s['code_prefixe']) ?></code></td>
          <td><?= sanitize($s['salle_defaut'] ?? '-') ?></td>
          <td><span class="badge bg-primary"><?= (int)$s['nb_tickets_today'] ?></span></td>
          <td>
            <?= $s['actif']
              ? '<span class="badge bg-success">Actif</span>'
              : '<span class="badge bg-secondary">Inactif</span>' ?>
          </td>
          <td>
            <div class="d-flex gap-1">
              <!-- Éditer -->
              <button class="btn btn-sm btn-outline-primary"
                      onclick="editService(<?= $s['id'] ?>,'<?= sanitize($s['nom_service']) ?>','<?= sanitize($s['salle_defaut'] ?? '') ?>')">
                <i class="bi bi-pencil"></i>
              </button>
              <!-- Toggle actif -->
              <form method="POST" class="d-inline">
                <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="service_id" value="<?= $s['id'] ?>">
                <input type="hidden" name="actif" value="<?= $s['actif'] ? 0 : 1 ?>">
                <button type="submit" class="btn btn-sm <?= $s['actif'] ? 'btn-outline-danger' : 'btn-outline-success' ?>">
                  <i class="bi bi-<?= $s['actif'] ? 'pause-circle' : 'play-circle' ?>"></i>
                </button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Nouveau service -->
<div class="modal fade" id="modal-new-service" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header" style="background:var(--hc-blue-dark);color:#fff">
        <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Nouveau service</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <div class="modal-body row g-3">
          <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
          <input type="hidden" name="action" value="create">
          <div class="col-12">
            <label class="form-label">Nom du service *</label>
            <input type="text" class="form-control" name="nom_service" required placeholder="Ex: Radiologie">
          </div>
          <div class="col-6">
            <label class="form-label">Code préfixe * <small class="text-muted">(unique, 2-10 car.)</small></label>
            <input type="text" class="form-control text-uppercase" name="code_prefixe" required maxlength="10" placeholder="RAD">
          </div>
          <div class="col-6">
            <label class="form-label">Salle/Bureau par défaut</label>
            <input type="text" class="form-control" name="salle_defaut" placeholder="Bureau 1">
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
          <button type="submit" class="btn btn-hc-primary"><i class="bi bi-save me-1"></i>Créer</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Éditer service -->
<div class="modal fade" id="modal-edit-service" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Modifier le service</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <div class="modal-body row g-3">
          <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
          <input type="hidden" name="action" value="edit">
          <input type="hidden" name="service_id" id="edit-sid">
          <div class="col-12">
            <label class="form-label">Nom du service *</label>
            <input type="text" class="form-control" name="nom_service" id="edit-nom" required>
          </div>
          <div class="col-12">
            <label class="form-label">Salle/Bureau par défaut</label>
            <input type="text" class="form-control" name="salle_defaut" id="edit-salle">
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
          <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Enregistrer</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function editService(id, nom, salle) {
  document.getElementById('edit-sid').value   = id;
  document.getElementById('edit-nom').value   = nom;
  document.getElementById('edit-salle').value = salle;
  new bootstrap.Modal(document.getElementById('modal-edit-service')).show();
}
</script>
<?php require_once INCLUDES_PATH . '/footer.php'; ?>
