<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAuth(['admin','superadmin']);
$user = currentUser();
$db   = getDB();

$error = $success = '';

// ── Traitement POST ───────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Erreur CSRF.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'create') {
            $login      = trim($_POST['login'] ?? '');
            $mdp        = $_POST['password'] ?? '';
            $role       = $_POST['role'] ?? '';
            $nomComplet = trim($_POST['nom_complet'] ?? '');
            $emailU     = trim($_POST['email'] ?? '');
            $serviceId  = ($_POST['service_id'] ?? '') ?: null;

            if (strlen($login) < 3 || strlen($mdp) < 6 || !$nomComplet || !in_array($role, ['admin','secretaire','medecin'])) {
                $error = 'Données invalides (login ≥ 3 car., mot de passe ≥ 6 car., rôle et nom requis).';
            } else {
                try {
                    $hash = password_hash($mdp, PASSWORD_BCRYPT);
                    $db->prepare("INSERT INTO users (login,password,role,nom_complet,email,service_id) VALUES (?,?,?,?,?,?)")
                       ->execute([$login, $hash, $role, $nomComplet, $emailU ?: null, $serviceId]);
                    $newId = $db->lastInsertId();
                    auditLog('CREATION_UTILISATEUR', $newId, 'users', ['login'=>$login,'role'=>$role]);
                    $success = "Utilisateur <strong>$login</strong> créé avec succès.";
                } catch (PDOException $e) {
                    $error = strpos($e->getMessage(),'Duplicate') !== false
                        ? "Le login \"$login\" est déjà utilisé." : $e->getMessage();
                }
            }
        } elseif ($action === 'toggle_actif') {
            $uid = (int)$_POST['user_id'];
            $actif = (int)$_POST['actif'];
            // Empêcher désactivation de soi-même
            if ($uid === $user['id']) { $error = 'Impossible de désactiver votre propre compte.'; }
            else {
                $db->prepare('UPDATE users SET actif=? WHERE id=?')->execute([$actif, $uid]);
                auditLog('TOGGLE_UTILISATEUR', $uid, 'users', ['actif'=>$actif]);
                $success = 'Compte ' . ($actif ? 'activé' : 'désactivé') . '.';
            }
        } elseif ($action === 'reset_password') {
            $uid  = (int)$_POST['user_id'];
            $newMdp = $_POST['new_password'] ?? '';
            if (strlen($newMdp) < 6) { $error = 'Mot de passe minimum 6 caractères.'; }
            else {
                $hash = password_hash($newMdp, PASSWORD_BCRYPT);
                $db->prepare('UPDATE users SET password=?,tentatives_echec=0,bloque_jusqu=NULL WHERE id=?')->execute([$hash,$uid]);
                auditLog('RESET_MDP_ADMIN', $uid, 'users');
                $success = 'Mot de passe réinitialisé.';
            }
        }
    }
}

$services = $db->query('SELECT id, nom_service FROM services WHERE actif=1 ORDER BY nom_service')->fetchAll();
$users    = $db->query("
    SELECT u.*, s.nom_service
    FROM users u
    LEFT JOIN services s ON s.id=u.service_id
    ORDER BY u.role, u.nom_complet
")->fetchAll();

$csrfToken = generateCsrfToken();
$pageTitle = 'Gestion Utilisateurs';
require_once INCLUDES_PATH . '/header.php';
?>
<meta name="csrf-token" content="<?= $csrfToken ?>">
<meta name="app-url" content="<?= APP_URL ?>">

<div class="d-flex align-items-center gap-2 mb-4">
  <a href="<?= APP_URL ?>/modules/admin/dashboard.php" class="btn btn-sm btn-outline-secondary">
    <i class="bi bi-arrow-left"></i>
  </a>
  <h4 class="mb-0 fw-bold" style="color:var(--hc-blue-dark)">
    <i class="bi bi-people me-2"></i>Gestion du Personnel
  </h4>
  <button class="btn btn-hc-primary ms-auto" data-bs-toggle="modal" data-bs-target="#modal-new-user">
    <i class="bi bi-person-plus me-1"></i>Nouvel utilisateur
  </button>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>

<div class="hc-card">
  <div class="table-responsive">
    <table class="table table-hc table-hover mb-0">
      <thead>
        <tr><th>Login</th><th>Nom complet</th><th>Rôle</th><th>Service</th><th>Statut</th><th>Dernière connexion</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
        <tr class="<?= !$u['actif'] ? 'opacity-50' : '' ?>">
          <td><code><?= sanitize($u['login']) ?></code></td>
          <td><?= sanitize($u['nom_complet']) ?></td>
          <td>
            <?php $roleCols = ['superadmin'=>'danger','admin'=>'primary','secretaire'=>'info','medecin'=>'success']; ?>
            <span class="badge bg-<?= $roleCols[$u['role']] ?? 'secondary' ?>"><?= strtoupper($u['role']) ?></span>
          </td>
          <td><small><?= sanitize($u['nom_service'] ?? '-') ?></small></td>
          <td>
            <?php if ($u['actif']): ?>
              <span class="badge bg-success"><i class="bi bi-circle-fill me-1" style="font-size:7px"></i>Actif</span>
            <?php else: ?>
              <span class="badge bg-secondary">Inactif</span>
            <?php endif; ?>
          </td>
          <td><small class="text-muted"><?= $u['derniere_connexion'] ? date('d/m/Y H:i', strtotime($u['derniere_connexion'])) : 'Jamais' ?></small></td>
          <td>
            <?php if ($u['role'] !== 'superadmin' || $user['role'] === 'superadmin'): ?>
            <div class="d-flex gap-1">
              <!-- Toggle actif -->
              <form method="POST" class="d-inline">
                <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                <input type="hidden" name="action" value="toggle_actif">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <input type="hidden" name="actif" value="<?= $u['actif'] ? 0 : 1 ?>">
                <button type="submit" class="btn btn-sm <?= $u['actif'] ? 'btn-outline-danger' : 'btn-outline-success' ?>"
                        title="<?= $u['actif'] ? 'Désactiver' : 'Activer' ?>">
                  <i class="bi bi-<?= $u['actif'] ? 'person-x' : 'person-check' ?>"></i>
                </button>
              </form>
              <!-- Reset MDP -->
              <button class="btn btn-sm btn-outline-warning" title="Réinitialiser MDP"
                      onclick="resetMdp(<?= $u['id'] ?>,'<?= sanitize($u['login']) ?>')">
                <i class="bi bi-key"></i>
              </button>
            </div>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Nouvel utilisateur -->
<div class="modal fade" id="modal-new-user" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header" style="background:var(--hc-blue-dark);color:#fff">
        <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Créer un utilisateur</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <div class="modal-body">
          <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
          <input type="hidden" name="action" value="create">
          <div class="row g-3">
            <div class="col-6">
              <label class="form-label">Nom complet *</label>
              <input type="text" class="form-control" name="nom_complet" required>
            </div>
            <div class="col-6">
              <label class="form-label">Login *</label>
              <input type="text" class="form-control" name="login" required minlength="3">
            </div>
            <div class="col-6">
              <label class="form-label">Mot de passe *</label>
              <input type="password" class="form-control" name="password" required minlength="6" placeholder="Min. 6 car.">
            </div>
            <div class="col-6">
              <label class="form-label">Rôle *</label>
              <select class="form-select" name="role" required>
                <option value="">-- Choisir --</option>
                <?php if ($user['role'] === 'superadmin'): ?><option value="admin">Admin</option><?php endif; ?>
                <option value="secretaire">Secrétaire</option>
                <option value="medecin">Médecin</option>
              </select>
            </div>
            <div class="col-6">
              <label class="form-label">Service</label>
              <select class="form-select" name="service_id">
                <option value="">-- Aucun --</option>
                <?php foreach ($services as $s): ?>
                <option value="<?= $s['id'] ?>"><?= sanitize($s['nom_service']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-6">
              <label class="form-label">Email (pour reset MDP)</label>
              <input type="email" class="form-control" name="email">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
          <button type="submit" class="btn btn-hc-primary"><i class="bi bi-save me-1"></i>Créer</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Reset MDP -->
<div class="modal fade" id="modal-reset-mdp" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content">
      <div class="modal-header bg-warning">
        <h5 class="modal-title"><i class="bi bi-key me-2"></i>Réinitialiser MDP</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <div class="modal-body">
          <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
          <input type="hidden" name="action" value="reset_password">
          <input type="hidden" name="user_id" id="reset-uid">
          <p>Nouveau mot de passe pour <strong id="reset-login"></strong> :</p>
          <input type="password" class="form-control" name="new_password" required minlength="6" placeholder="Min. 6 caractères">
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
          <button type="submit" class="btn btn-warning"><i class="bi bi-key me-1"></i>Réinitialiser</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function resetMdp(uid, login) {
  document.getElementById('reset-uid').value   = uid;
  document.getElementById('reset-login').textContent = login;
  new bootstrap.Modal(document.getElementById('modal-reset-mdp')).show();
}
</script>
<?php require_once INCLUDES_PATH . '/footer.php'; ?>
