<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAuth(['admin','superadmin']);
$user = currentUser();
$db   = getDB();

// Stats globales du jour
// $stats = $db->query("
//     SELECT
//       (SELECT COUNT(*) FROM tickets WHERE DATE(cree_le)=CURDATE()) as tickets_jour,
//       (SELECT COUNT(*) FROM tickets WHERE statut_ticket='en_attente' AND DATE(cree_le)=CURDATE()) as en_attente,
//       (SELECT COUNT(*) FROM patients) as total_patients,
//       (SELECT COUNT(*) FROM users WHERE actif=1) as users_actifs,
//       (SELECT COUNT(*) FROM email_logs WHERE DATE(envoye_le)=CURDATE() AND statut='envoye') as emails_envoyes,
//       (SELECT COUNT(*) FROM tickets WHERE TIMESTAMPDIFF(MINUTE,cree_le,NOW())>= ? AND statut_ticket='en_attente') as alertes
// ", [WAIT_ALERT_MINUTES])->fetch();

$stmt = $db->prepare("
    SELECT
      (SELECT COUNT(*) FROM tickets WHERE DATE(cree_le)=CURDATE()) as tickets_jour,
      (SELECT COUNT(*) FROM tickets WHERE statut_ticket='en_attente' AND DATE(cree_le)=CURDATE()) as en_attente,
      (SELECT COUNT(*) FROM patients) as total_patients,
      (SELECT COUNT(*) FROM users WHERE actif=1) as users_actifs,
      (SELECT COUNT(*) FROM email_logs WHERE DATE(envoye_le)=CURDATE() AND statut='envoye') as emails_envoyes,
      (SELECT COUNT(*) FROM tickets WHERE TIMESTAMPDIFF(MINUTE,cree_le,NOW())>= ? AND statut_ticket='en_attente') as alertes
");

$stmt->execute([WAIT_ALERT_MINUTES]);
$stats = $stmt->fetch();

// File par service
$filesParService = $db->query("
    SELECT s.nom_service, s.code_prefixe,
           SUM(t.statut_ticket='en_attente') as en_attente,
           SUM(t.statut_ticket='termine')    as termines,
           COUNT(t.id)                        as total
    FROM services s
    LEFT JOIN tickets t ON t.service_id=s.id AND DATE(t.cree_le)=CURDATE()
    WHERE s.actif=1
    GROUP BY s.id
    ORDER BY en_attente DESC
")->fetchAll();

$pageTitle = 'Administration';
require_once INCLUDES_PATH . '/header.php';
?>
<meta name="app-url" content="<?= APP_URL ?>">

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
  <div>
    <h4 class="mb-0 fw-bold" style="color:var(--hc-blue-dark)">
      <i class="bi bi-speedometer2 me-2"></i>Tableau de bord Administration
    </h4>
    <small class="text-muted">Bienvenue, <?= sanitize($user['nom_complet'] ?: $user['login']) ?> &bull; <?= date('d/m/Y H:i') ?></small>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <a href="<?= APP_URL ?>/modules/admin/users.php" class="btn btn-outline-primary btn-sm">
      <i class="bi bi-people me-1"></i>Utilisateurs
    </a>
    <a href="<?= APP_URL ?>/modules/admin/services.php" class="btn btn-outline-primary btn-sm">
      <i class="bi bi-hospital me-1"></i>Services
    </a>
    <a href="<?= APP_URL ?>/modules/admin/stats.php" class="btn btn-outline-primary btn-sm">
      <i class="bi bi-bar-chart me-1"></i>Statistiques
    </a>
    <?php if ($user['role'] === 'superadmin'): ?>
    <a href="<?= APP_URL ?>/modules/admin/logs.php" class="btn btn-outline-danger btn-sm">
      <i class="bi bi-journal-text me-1"></i>Audit
    </a>
    <?php endif; ?>
  </div>
</div>

<!-- Alertes -->
<?php if ($stats['alertes'] > 0): ?>
<div class="alert alert-danger d-flex align-items-center gap-2 mb-3">
  <i class="bi bi-exclamation-triangle-fill fs-4"></i>
  <strong><?= $stats['alertes'] ?> patient(s) en attente depuis plus de <?= WAIT_ALERT_MINUTES ?> minutes !</strong>
  <a href="<?= APP_URL ?>/modules/admin/stats.php" class="btn btn-sm btn-danger ms-auto">Voir</a>
</div>
<?php endif; ?>

<!-- KPI globaux -->
<div class="row g-3 mb-4">
  <?php foreach ([
    ['tickets_jour', 'Tickets aujourd\'hui', 'primary', 'ticket-perforated-fill'],
    ['en_attente',   'En attente',           'warning',  'people-fill'],
    ['emails_envoyes','Emails envoyés',       'success',  'envelope-check-fill'],
    ['alertes',      'Alertes > 45min',       'danger',   'exclamation-triangle-fill'],
  ] as [$key,$label,$col,$icon]): ?>
  <div class="col-6 col-xl-3">
    <div class="hc-stat">
      <div class="stat-icon" style="background:#f0f0f0">
        <i class="bi bi-<?= $icon ?> text-<?= $col ?>"></i>
      </div>
      <div>
        <div class="stat-val text-<?= $col ?>"><?= (int)($stats[$key] ?? 0) ?></div>
        <div class="stat-lbl"><?= $label ?></div>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <!-- Files par service -->
  <div class="col-lg-8">
    <div class="hc-card">
      <div class="hc-card-header">
        <div class="icon"><i class="bi bi-hospital"></i></div>
        <h5>État des services — Aujourd'hui</h5>
      </div>
      <div class="table-responsive">
        <table class="table table-hc table-hover mb-0">
          <thead>
            <tr><th>Service</th><th>Code</th><th>En attente</th><th>Terminés</th><th>Total</th><th>Statut</th></tr>
          </thead>
          <tbody>
            <?php foreach ($filesParService as $s): ?>
            <tr>
              <td class="fw-semibold"><?= sanitize($s['nom_service']) ?></td>
              <td><code><?= sanitize($s['code_prefixe']) ?></code></td>
              <td>
                <span class="badge <?= (int)$s['en_attente'] >= 20 ? 'bg-danger' : ((int)$s['en_attente'] >= 10 ? 'bg-warning text-dark' : 'bg-success') ?>">
                  <?= (int)$s['en_attente'] ?>
                </span>
              </td>
              <td><?= (int)$s['termines'] ?></td>
              <td><?= (int)$s['total'] ?></td>
              <td>
                <?php if ((int)$s['en_attente'] >= 20): ?>
                  <span class="badge bg-danger"><i class="bi bi-exclamation-triangle me-1"></i>File pleine</span>
                <?php elseif ((int)$s['en_attente'] >= 10): ?>
                  <span class="badge bg-warning text-dark">Chargé</span>
                <?php else: ?>
                  <span class="badge bg-success">Normal</span>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Raccourcis admin -->
  <div class="col-lg-4">
    <div class="hc-card mb-3">
      <div class="hc-card-header">
        <div class="icon"><i class="bi bi-gear-fill"></i></div>
        <h5>Administration</h5>
      </div>
      <div class="d-grid gap-2">
        <a href="<?= APP_URL ?>/modules/admin/users.php" class="btn btn-outline-primary">
          <i class="bi bi-person-plus me-2"></i>Gérer le personnel
        </a>
        <a href="<?= APP_URL ?>/modules/admin/services.php" class="btn btn-outline-primary">
          <i class="bi bi-hospital me-2"></i>Gérer les services
        </a>
        <a href="<?= APP_URL ?>/modules/admin/stats.php" class="btn btn-outline-success">
          <i class="bi bi-graph-up me-2"></i>Voir les statistiques
        </a>
        <?php if ($user['role'] === 'superadmin'): ?>
        <a href="<?= APP_URL ?>/modules/admin/logs.php" class="btn btn-outline-danger">
          <i class="bi bi-journal-text me-2"></i>Journal d'audit
        </a>
        <?php endif; ?>
      </div>
    </div>

    <div class="hc-card">
      <div class="hc-card-header">
        <div class="icon"><i class="bi bi-info-circle"></i></div>
        <h5>Système</h5>
      </div>
      <div class="small">
        <div class="d-flex justify-content-between py-1 border-bottom">
          <span class="text-muted">Total patients</span>
          <strong><?= (int)$stats['total_patients'] ?></strong>
        </div>
        <div class="d-flex justify-content-between py-1 border-bottom">
          <span class="text-muted">Utilisateurs actifs</span>
          <strong><?= (int)$stats['users_actifs'] ?></strong>
        </div>
        <div class="d-flex justify-content-between py-1 border-bottom">
          <span class="text-muted">Emails envoyés (jour)</span>
          <strong class="text-success"><?= (int)$stats['emails_envoyes'] ?></strong>
        </div>
        <div class="d-flex justify-content-between py-1">
          <span class="text-muted">Seuil alerte attente</span>
          <strong><?= WAIT_ALERT_MINUTES ?> min</strong>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
