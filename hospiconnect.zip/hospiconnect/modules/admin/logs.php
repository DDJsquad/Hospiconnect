<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAuth(['superadmin']);
$db = getDB();

// Filtres
$filtreUser   = (int)($_GET['user_id'] ?? 0);
$filtreAction = trim($_GET['action'] ?? '');
$filtreDate   = trim($_GET['date'] ?? date('Y-m-d'));
$page         = max(1, (int)($_GET['p'] ?? 1));
$perPage      = 50;
$offset       = ($page - 1) * $perPage;

$where  = ['DATE(l.cree_le) = ?'];
$params = [$filtreDate];

if ($filtreUser)   { $where[] = 'l.user_id = ?'; $params[] = $filtreUser; }
if ($filtreAction) { $where[] = 'l.action LIKE ?'; $params[] = "%$filtreAction%"; }

$whereSQL = implode(' AND ', $where);

$total = $db->prepare("SELECT COUNT(*) FROM audit_logs l WHERE $whereSQL");
$total->execute($params);
$totalRows = $total->fetchColumn();

$stmt = $db->prepare("
    SELECT l.*, u.login, u.nom_complet
    FROM audit_logs l
    LEFT JOIN users u ON u.id = l.user_id
    WHERE $whereSQL
    ORDER BY l.cree_le DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$logs = $stmt->fetchAll();

$users = $db->query('SELECT id, login, nom_complet FROM users ORDER BY nom_complet')->fetchAll();

$actionColors = [
    'CONNEXION_SUCCES'       => 'success',
    'CONNEXION_ECHEC'        => 'warning',
    'CONNEXION_ECHEC_BLOCAGE'=> 'danger',
    'DECONNEXION'            => 'secondary',
    'CREATION_TICKET'        => 'primary',
    'APPEL_TICKET'           => 'info',
    'TICKET_TERMINE'         => 'success',
    'TICKET_ABSENT'          => 'warning',
    'TRANSFERT_TICKET'       => 'primary',
    'EXAMENS_PRETS'          => 'success',
    'CREATION_PATIENT'       => 'info',
    'CREATION_UTILISATEUR'   => 'primary',
    'RESET_MDP_ADMIN'        => 'warning',
];

$pageTitle = 'Journal d\'Audit';
require_once INCLUDES_PATH . '/header.php';
?>
<div class="d-flex align-items-center gap-2 mb-4 flex-wrap">
  <a href="<?= APP_URL ?>/modules/admin/dashboard.php" class="btn btn-sm btn-outline-secondary">
    <i class="bi bi-arrow-left"></i>
  </a>
  <h4 class="mb-0 fw-bold text-danger">
    <i class="bi bi-journal-text me-2"></i>Journal d'Audit
  </h4>
  <span class="badge bg-secondary ms-2"><?= number_format($totalRows) ?> entrées</span>
</div>

<!-- Filtres -->
<div class="hc-card mb-3">
  <form method="GET" class="row g-2 align-items-end">
    <div class="col-md-3">
      <label class="form-label">Date</label>
      <input type="date" class="form-control" name="date" value="<?= htmlspecialchars($filtreDate) ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">Utilisateur</label>
      <select class="form-select" name="user_id">
        <option value="">Tous</option>
        <?php foreach ($users as $u): ?>
        <option value="<?= $u['id'] ?>" <?= $filtreUser == $u['id'] ? 'selected' : '' ?>>
          <?= sanitize($u['login']) ?> — <?= sanitize($u['nom_complet']) ?>
        </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label">Action</label>
      <input type="text" class="form-control" name="action" value="<?= htmlspecialchars($filtreAction) ?>" placeholder="Ex: CONNEXION, TICKET...">
    </div>
    <div class="col-md-2">
      <button type="submit" class="btn btn-hc-primary w-100"><i class="bi bi-funnel me-1"></i>Filtrer</button>
    </div>
  </form>
</div>

<div class="hc-card">
  <div class="table-responsive">
    <table class="table table-hc table-sm table-hover mb-0">
      <thead>
        <tr><th>Date/Heure</th><th>Utilisateur</th><th>Action</th><th>Table</th><th>IP</th><th>Détails</th></tr>
      </thead>
      <tbody>
        <?php if (empty($logs)): ?>
        <tr><td colspan="6" class="text-center text-muted py-4">Aucun log pour ces critères.</td></tr>
        <?php endif; ?>
        <?php foreach ($logs as $l): ?>
        <tr>
          <td><small><?= date('d/m/Y H:i:s', strtotime($l['cree_le'])) ?></small></td>
          <td>
            <small>
              <?php if ($l['login']): ?>
                <code><?= sanitize($l['login']) ?></code>
                <span class="text-muted"> — <?= sanitize($l['nom_complet']) ?></span>
              <?php else: ?>
                <span class="text-muted">Système</span>
              <?php endif; ?>
            </small>
          </td>
          <td>
            <?php $col = $actionColors[$l['action']] ?? 'secondary'; ?>
            <span class="badge bg-<?= $col ?>" style="font-size:10px"><?= sanitize($l['action']) ?></span>
          </td>
          <td><small class="text-muted"><?= sanitize($l['table_cible'] ?? '-') ?> <?= $l['entite_id'] ? '#'.$l['entite_id'] : '' ?></small></td>
          <td><code style="font-size:11px"><?= sanitize($l['ip_address'] ?? '-') ?></code></td>
          <td>
            <?php if ($l['details']): ?>
            <button class="btn btn-sm btn-outline-secondary py-0 px-1"
                    style="font-size:11px"
                    onclick="showDetails(<?= htmlspecialchars($l['details']) ?>)">
              <i class="bi bi-eye"></i>
            </button>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($totalRows > $perPage): ?>
  <div class="d-flex justify-content-center mt-3">
    <nav>
      <ul class="pagination pagination-sm">
        <?php
        $totalPages = ceil($totalRows / $perPage);
        for ($i = max(1, $page-2); $i <= min($totalPages, $page+2); $i++):
          $q = http_build_query(array_merge($_GET, ['p' => $i]));
        ?>
        <li class="page-item <?= $i === $page ? 'active' : '' ?>">
          <a class="page-link" href="?<?= $q ?>"><?= $i ?></a>
        </li>
        <?php endfor; ?>
      </ul>
    </nav>
  </div>
  <?php endif; ?>
</div>

<!-- Modal détails -->
<div class="modal fade" id="modal-details" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Détails de l'action</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <pre id="details-content" class="bg-light p-3 rounded" style="font-size:12px;max-height:400px;overflow-y:auto"></pre>
      </div>
    </div>
  </div>
</div>

<script>
function showDetails(data) {
  document.getElementById('details-content').textContent = JSON.stringify(data, null, 2);
  new bootstrap.Modal(document.getElementById('modal-details')).show();
}
</script>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
