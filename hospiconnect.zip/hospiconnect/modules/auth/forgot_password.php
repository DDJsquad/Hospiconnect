<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$msg   = '';
$type  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $msg = 'Erreur de sécurité.'; $type = 'danger';
    } else {
        $email = trim($_POST['email'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $msg = 'Adresse email invalide.'; $type = 'danger';
        } else {
            $db = getDB();
            $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND role != 'superadmin' AND actif = 1 LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            // Toujours afficher le même message (sécurité)
            $msg  = 'Si cet email est enregistré, un lien de réinitialisation vous a été envoyé.';
            $type = 'success';
            if ($user) {
                $token  = bin2hex(random_bytes(32));
                $expire = date('Y-m-d H:i:s', time() + 3600);
                $db->prepare('UPDATE users SET reset_token=?, reset_token_expire=? WHERE id=?')
                   ->execute([$token, $expire, $user['id']]);
                $link = APP_URL . '/modules/auth/reset_password.php?token=' . $token;
                $subject = APP_ETABLISSEMENT . ' - Réinitialisation de mot de passe';
                $body = "<p>Bonjour <strong>{$user['nom_complet']}</strong>,</p>
                         <p>Cliquez sur le lien ci-dessous pour réinitialiser votre mot de passe (valable 1 heure) :</p>
                         <p><a href='$link'>$link</a></p>
                         <p>Si vous n'êtes pas à l'origine de cette demande, ignorez ce message.</p>";
                sendEmail($email, $subject, $body, 0, 0, 'reinit_mdp');
                auditLog('RESET_MDP_DEMANDE', $user['id'], 'users');
            }
        }
    }
}
$csrfToken = generateCsrfToken();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mot de passe oublié — <?= APP_ETABLISSEMENT ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/hospiconnect.css">
</head>
<body>
<div class="hc-login-wrapper">
  <div class="hc-login-card">
    <div class="hc-login-header">
      <img src="<?= APP_URL ?>/assets/img/logo_clinique.png" alt="Logo">
      <h1><?= APP_ETABLISSEMENT ?></h1>
      <p>Réinitialisation du mot de passe</p>
    </div>
    <div class="hc-login-body">
      <?php if ($msg): ?>
      <div class="alert alert-<?= $type ?> py-2"><?= sanitize($msg) ?></div>
      <?php endif; ?>
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
        <div class="mb-3">
          <label class="form-label"><i class="bi bi-envelope me-1"></i>Adresse email professionnelle</label>
          <input type="email" class="form-control form-control-lg" name="email" required autofocus>
        </div>
        <button type="submit" class="btn btn-hc-primary w-100 btn-lg">
          <i class="bi bi-send me-2"></i>Envoyer le lien
        </button>
      </form>
      <div class="text-center mt-3">
        <a href="<?= APP_URL ?>/index.php" class="text-muted small">
          <i class="bi bi-arrow-left me-1"></i>Retour à la connexion
        </a>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
