<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$token = trim($_GET['token'] ?? '');
$error = $success = '';

if (!$token) redirect(APP_URL . '/index.php');

$db   = getDB();
$stmt = $db->prepare("SELECT * FROM users WHERE reset_token=? AND reset_token_expire > NOW() AND actif=1 LIMIT 1");
$stmt->execute([$token]);
$user = $stmt->fetch();

if (!$user) {
    $error = 'Lien invalide ou expiré. Veuillez refaire une demande.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $user) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Erreur de sécurité.';
    } else {
        $mdp     = $_POST['password'] ?? '';
        $confirm = $_POST['password_confirm'] ?? '';
        if (strlen($mdp) < 6) {
            $error = 'Mot de passe minimum 6 caractères.';
        } elseif ($mdp !== $confirm) {
            $error = 'Les deux mots de passe ne correspondent pas.';
        } else {
            $hash = password_hash($mdp, PASSWORD_BCRYPT);
            $db->prepare("UPDATE users SET password=?, reset_token=NULL, reset_token_expire=NULL, tentatives_echec=0, bloque_jusqu=NULL WHERE id=?")
               ->execute([$hash, $user['id']]);
            auditLog('RESET_MDP_TOKEN', $user['id'], 'users');
            $success = 'Mot de passe réinitialisé avec succès. Vous pouvez maintenant vous connecter.';
            $user = null;
        }
    }
}

$csrfToken = generateCsrfToken();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nouveau mot de passe — <?= APP_ETABLISSEMENT ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/hospiconnect.css">
</head>
<body>
<div class="hc-login-wrapper">
  <div class="hc-login-card">
    <div class="hc-login-header">
      <img src="<?= APP_URL ?>/assets/img/logo_clinique.png" alt="Logo">
      <h1><?= APP_ETABLISSEMENT ?></h1>
      <p>Nouveau mot de passe</p>
    </div>
    <div class="hc-login-body">
      <?php if ($error): ?>
      <div class="alert alert-danger py-2"><?= sanitize($error) ?></div>
      <?php endif; ?>
      <?php if ($success): ?>
      <div class="alert alert-success py-2"><?= sanitize($success) ?></div>
      <a href="<?= APP_URL ?>/index.php" class="btn btn-hc-primary w-100">
        <i class="bi bi-box-arrow-in-right me-1"></i>Se connecter
      </a>
      <?php elseif ($user): ?>
      <p class="text-muted small">Bonjour <strong><?= sanitize($user['nom_complet']) ?></strong>, définissez votre nouveau mot de passe.</p>
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
        <div class="mb-3">
          <label class="form-label">Nouveau mot de passe *</label>
          <input type="password" class="form-control form-control-lg" name="password" required minlength="6" autofocus>
        </div>
        <div class="mb-4">
          <label class="form-label">Confirmer le mot de passe *</label>
          <input type="password" class="form-control form-control-lg" name="password_confirm" required minlength="6">
        </div>
        <button type="submit" class="btn btn-hc-primary w-100 btn-lg">
          <i class="bi bi-shield-check me-2"></i>Enregistrer
        </button>
      </form>
      <?php endif; ?>
      <?php if (!$success): ?>
      <div class="text-center mt-3">
        <a href="<?= APP_URL ?>/index.php" class="text-muted small">
          <i class="bi bi-arrow-left me-1"></i>Retour à la connexion
        </a>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
