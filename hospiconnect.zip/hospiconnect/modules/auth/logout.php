<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

if (isLoggedIn()) {
    auditLog('DECONNEXION', $_SESSION['user_id'], 'users');
}
session_destroy();
redirect(APP_URL . '/index.php?logout=1');
