<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAuth(['medecin']);
$user = currentUser();
$db   = getDB();
$serviceId = $user['service_id'];

// Nom service
$stmt = $db->prepare('SELECT nom_service FROM services WHERE id=?');
$stmt->execute([$serviceId]);
$nomService = $stmt->fetchColumn() ?: 'Mon service';

// Stats du jour
$stmtStats = $db->prepare("
    SELECT
      SUM(statut_ticket='en_attente') as en_attente,
      SUM(statut_ticket='appele')     as appeles,
      SUM(statut_ticket='termine')    as termines,
      SUM(statut_ticket='absent')     as absents
    FROM tickets WHERE service_id=? AND DATE(cree_le)=CURDATE()
");
$stmtStats->execute([$serviceId]);
$stats = $stmtStats->fetch();

$pageTitle = 'File d\'attente — ' . $nomService;
require_once INCLUDES_PATH . '/header.php';
?>
<meta name="csrf-token" content="<?= generateCsrfToken() ?>">
<meta name="polling-interval" content="<?= POLLING_INTERVAL ?>">
<meta name="app-url" content="<?= APP_URL ?>">

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
  <div>
    <h4 class="mb-0 fw-bold" style="color:var(--hc-blue-dark)">
      <i class="bi bi-heart-pulse me-2"></i>File d'attente — <?= sanitize($nomService) ?>
    </h4>
    <small class="text-muted"><?= sanitize($user['nom_complet']) ?> &bull; <?= date('d/m/Y') ?></small>
  </div>
  <button class="btn btn-success btn-lg" id="btn-appeler-suivant">
    <i class="bi bi-megaphone me-2"></i>Appeler le suivant
  </button>
</div>

<!-- KPI médecin -->
<div class="row g-3 mb-4">
  <?php foreach ([
    ['en_attente', 'En attente',  'primary', 'people-fill'],
    ['appeles',    'Appelés',     'warning',  'megaphone-fill'],
    ['termines',   'Terminés',    'success',  'check-circle-fill'],
    ['absents',    'Absents',     'secondary','person-x-fill'],
  ] as [$key, $label, $col, $icon]): ?>
  <div class="col-6 col-xl-3">
    <div class="hc-stat">
      <div class="stat-icon" style="background:var(--bs-<?= $col ?>-bg, #f0f0f0);color:var(--bs-<?= $col ?>)">
        <i class="bi bi-<?= $icon ?>"></i>
      </div>
      <div>
        <div class="stat-val text-<?= $col ?>" id="stat-<?= $key ?>"><?= (int)($stats[$key] ?? 0) ?></div>
        <div class="stat-lbl"><?= $label ?></div>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <!-- File d'attente -->
  <div class="col-lg-8">
    <div class="hc-card">
      <div class="hc-card-header">
        <div class="icon"><i class="bi bi-list-ol"></i></div>
        <h5>Patients en attente</h5>
        <span class="badge bg-danger ms-auto" id="queue-count">0</span>
        <span class="badge bg-success ms-1"><i class="bi bi-circle-fill me-1" style="font-size:8px"></i>Live</span>
      </div>
      <div id="queue-container">
        <div class="text-center py-4 text-muted">
          <div class="spinner-border spinner-border-sm me-2"></div>Chargement...
        </div>
      </div>
    </div>
  </div>

  <!-- Consultation en cours + légende -->
  <div class="col-lg-4">
    <!-- Patient en cours -->
    <div class="hc-card mb-3" id="panel-en-cours" style="display:none">
      <div class="hc-card-header">
        <div class="icon" style="background:#d1fae5;color:#065f46"><i class="bi bi-person-check"></i></div>
        <h5>En consultation</h5>
      </div>
      <div id="current-patient-info"></div>
      <div class="mt-3">
        <label class="form-label small">Observation (optionnelle)</label>
        <textarea class="form-control form-control-sm" id="obs-text" rows="3" placeholder="Notez une observation..."></textarea>
        <button class="btn btn-sm btn-outline-secondary mt-1 w-100" id="btn-save-obs">
          <i class="bi bi-save me-1"></i>Sauvegarder
        </button>
      </div>
      <button class="btn btn-danger w-100 mt-3" id="btn-cloturer">
        <i class="bi bi-check2-circle me-2"></i>Clôturer la consultation
      </button>
    </div>

    <!-- Légende priorités -->
    <div class="hc-card">
      <div class="hc-card-header">
        <div class="icon"><i class="bi bi-info-circle"></i></div>
        <h5>Légende</h5>
      </div>
      <div class="d-flex flex-column gap-2">
        <div class="ticket-row urgence p-2"><small><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i><strong>Urgence</strong> — Priorité absolue</small></div>
        <div class="ticket-row prioritaire p-2"><small><i class="bi bi-arrow-up-circle-fill text-warning me-2"></i><strong>Prioritaire</strong> — Passage accéléré</small></div>
        <div class="ticket-row standard p-2"><small><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Standard</strong> — File normale</small></div>
        <div class="p-2 border rounded" style="border-left:4px solid var(--hc-red) !important;background:#fff5f5">
          <small><i class="bi bi-clock-fill text-danger me-2"></i>Clignotant = attente > 45 min</small>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- <script>
let currentTicketId = null;

// Polling
startPolling('<?= APP_URL ?>/api/queue.php?service_id=<?= (int)$serviceId ?>',
  'queue-container', function(data, container) {
    renderQueueMedecin(data, container);
    updateStats(data.stats || {});
  });

function updateStats(s) {
  ['en_attente','appeles','termines','absents'].forEach(k => {
    const el = document.getElementById('stat-' + k);
    if (el && s[k] !== undefined) el.textContent = s[k];
  });
}

// Appeler le suivant
document.getElementById('btn-appeler-suivant').addEventListener('click', async function() {
  const res = await hcFetch('<?= APP_URL ?>/api/ticket_action.php',
    { action: 'appeler_suivant', service_id: <?= (int)$serviceId ?> }, 'POST');
  if (res.success) {
    showToast('Ticket ' + res.numero + ' appelé !', 'success');
    currentTicketId = res.ticket_id;
    afficherPatientEnCours(res);
  } else {
    showToast(res.error || 'Aucun patient en attente', 'warning');
  }
});

function afficherPatientEnCours(data) {
  const panel = document.getElementById('panel-en-cours');
  const info  = document.getElementById('current-patient-info');
  panel.style.display = '';
  info.innerHTML = `
    <div class="text-center mb-3">
      <div class="display-6 fw-bold text-primary">${data.numero || ''}</div>
      <div class="fs-5 fw-semibold">${data.nom || ''}</div>
      <small class="text-muted">${data.motif || ''}</small>
    </div>`;
  document.getElementById('obs-text').value = '';
  document.getElementById('btn-cloturer').dataset.ticketId = data.ticket_id;
}

// Clôturer
document.getElementById('btn-cloturer').addEventListener('click', async function() {
  if (!this.dataset.ticketId) return;
  const ok = await hcConfirm('Clôturer cette consultation ?');
  if (!ok) return;
  const obs = document.getElementById('obs-text').value;
  const res = await hcFetch('<?= APP_URL ?>/api/ticket_action.php',
    { ticket_id: this.dataset.ticketId, action: 'terminer', observation: obs }, 'POST');
  if (res.success) {
    showToast('Consultation clôturée', 'success');
    document.getElementById('panel-en-cours').style.display = 'none';
    currentTicketId = null;
  } else showToast(res.error || 'Erreur', 'danger');
});

// Sauvegarder observation
document.getElementById('btn-save-obs').addEventListener('click', async function() {
  if (!currentTicketId) return;
  const obs = document.getElementById('obs-text').value;
  const res = await hcFetch('<?= APP_URL ?>/api/ticket_action.php',
    { ticket_id: currentTicketId, action: 'observation', observation: obs }, 'POST');
  if (res.success) showToast('Observation sauvegardée', 'success');
  else showToast(res.error || 'Erreur', 'danger');
});
</script> -->


<script src="<?= APP_URL ?>/assets/js/hospiconnect.js"></script>
<script>
let currentTicketId = null;

document.addEventListener('DOMContentLoaded', function() {

  startPolling('<?= APP_URL ?>/api/queue.php?service_id=<?= (int)$serviceId ?>',
    'queue-container', function(data, container) {
      renderQueueMedecin(data, container);
      updateStats(data.stats || {});
  });

  function updateStats(s) {
    ['en_attente','appeles','termines','absents'].forEach(function(k) {
      const el = document.getElementById('stat-' + k);
      if (el && s[k] !== undefined) el.textContent = s[k];
    });
  }

  document.getElementById('btn-appeler-suivant').addEventListener('click', async function() {
    const res = await hcFetch('<?= APP_URL ?>/api/ticket_action.php',
      { action: 'appeler_suivant', service_id: <?= (int)$serviceId ?> }, 'POST');
    if (res.success) {
      showToast('Ticket ' + res.numero + ' appelé !', 'success');
      currentTicketId = res.ticket_id;
      afficherPatientEnCours(res);
    } else {
      showToast(res.error || 'Aucun patient en attente', 'warning');
    }
  });

  function afficherPatientEnCours(data) {
    const panel = document.getElementById('panel-en-cours');
    const info  = document.getElementById('current-patient-info');
    panel.style.display = '';
    info.innerHTML = `
      <div class="text-center mb-3">
        <div class="display-6 fw-bold text-primary">${data.numero || ''}</div>
        <div class="fs-5 fw-semibold">${data.nom || ''}</div>
        <small class="text-muted">${data.motif || ''}</small>
      </div>`;
    document.getElementById('obs-text').value = '';
    document.getElementById('btn-cloturer').dataset.ticketId = data.ticket_id;
  }

  document.getElementById('btn-cloturer').addEventListener('click', async function() {
    if (!this.dataset.ticketId) return;
    const ok = await hcConfirm('Clôturer cette consultation ?');
    if (!ok) return;
    const obs = document.getElementById('obs-text').value;
    const res = await hcFetch('<?= APP_URL ?>/api/ticket_action.php',
      { ticket_id: this.dataset.ticketId, action: 'terminer', observation: obs }, 'POST');
    if (res.success) {
      showToast('Consultation clôturée', 'success');
      document.getElementById('panel-en-cours').style.display = 'none';
      currentTicketId = null;
    } else showToast(res.error || 'Erreur', 'danger');
  });

  document.getElementById('btn-save-obs').addEventListener('click', async function() {
    if (!currentTicketId) return;
    const obs = document.getElementById('obs-text').value;
    const res = await hcFetch('<?= APP_URL ?>/api/ticket_action.php',
      { ticket_id: currentTicketId, action: 'observation', observation: obs }, 'POST');
    if (res.success) showToast('Observation sauvegardée', 'success');
    else showToast(res.error || 'Erreur', 'danger');
  });

});
</script>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
<?php require_once INCLUDES_PATH . '/footer.php'; ?>
