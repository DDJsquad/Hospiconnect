<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';
// Page publique - pas d'auth requise
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Salle d'attente — <?= APP_ETABLISSEMENT ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/hospiconnect.css">
  <meta name="app-url" content="<?= APP_URL ?>">
  <style>
    @keyframes flash-ticket {
      0%,100% { transform: scale(1); opacity:1; }
      50%      { transform: scale(1.04); opacity:.85; }
    }
    .flash { animation: flash-ticket .6s ease 3; }
    #kiosk-clock { font-size: 2rem; font-weight: 700; color: #D5E8F0; }
    .kiosk-scrolling {
      white-space: nowrap;
      overflow: hidden;
    }
    .kiosk-scrolling span {
      display: inline-block;
      animation: scroll-msg 20s linear infinite;
      color: rgba(255,255,255,.5);
      font-size: .9rem;
    }
    @keyframes scroll-msg {
      from { transform: translateX(100vw); }
      to   { transform: translateX(-100%); }
    }
  </style>
</head>
<body class="hc-kiosk">

<!-- Header -->
<div class="kiosk-header">
  <img src="<?= APP_URL ?>/assets/img/logo_clinique.png" alt="Logo">
  <div>
    <div style="font-size:1.5rem;font-weight:800"><?= APP_ETABLISSEMENT ?></div>
    <div style="font-size:.9rem;opacity:.7">Salle d'attente — Veuillez surveiller l'écran</div>
  </div>
  <div class="ms-auto text-end">
    <div id="kiosk-clock">--:--:--</div>
    <div style="font-size:.8rem;opacity:.5"><?= date('d/m/Y') ?></div>
  </div>
</div>

<!-- Message défilant -->
<div class="kiosk-scrolling px-4 py-2" style="background:rgba(0,0,0,.2)">
  <span>Bienvenue à la <?= APP_ETABLISSEMENT ?> &bull; Votre santé est notre priorité &bull; Merci de rester dans la salle d'attente et de surveiller l'écran &bull; En cas d'urgence, signalez-vous à l'accueil &bull;</span>
</div>

<div class="row g-0" style="padding:0 8px">
  <!-- Ticket en cours - panneau principal -->
  <div class="col-md-7">
    <div id="kiosk-current" class="current-ticket" style="min-height:280px;display:flex;flex-direction:column;align-items:center;justify-content:center">
      <div style="font-size:1rem;color:rgba(255,255,255,.6);margin-bottom:8px;text-transform:uppercase;letter-spacing:2px">
        <i class="bi bi-megaphone me-2"></i>Ticket appelé
      </div>
      <div class="num" id="kiosk-num">---</div>
      <div class="salle" id="kiosk-salle">En attente d'appel</div>
    </div>
  </div>

  <!-- Historique -->
  <div class="col-md-5">
    <div style="padding:20px 12px 0">
      <div style="color:rgba(255,255,255,.4);font-size:.85rem;text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;padding-left:8px">
        <i class="bi bi-clock-history me-1"></i>Derniers tickets
      </div>
      <div id="kiosk-list">
        <div class="ticket-list-item">
          <span class="t-num" style="color:rgba(255,255,255,.3)">En attente...</span>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bouton fullscreen -->
<div style="position:fixed;bottom:16px;right:16px;z-index:10">
  <button class="btn btn-sm btn-outline-light opacity-50" onclick="toggleFullscreen()">
    <i class="bi bi-fullscreen" id="fs-icon"></i>
  </button>
</div>

<script src="<?= APP_URL ?>/assets/js/hospiconnect.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
  // Horloge
  const clockEl = document.getElementById('kiosk-clock');
  setInterval(() => {
    clockEl.textContent = new Date().toLocaleTimeString('fr-FR',
      { hour:'2-digit', minute:'2-digit', second:'2-digit' });
  }, 1000);

  // Kiosque
  let lastTicketId = null;
  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

  function playGong() {
    try {
      [660, 880, 1100].forEach((freq, i) => {
        const osc  = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain); gain.connect(audioCtx.destination);
        osc.type = 'sine'; osc.frequency.value = freq;
        const t = audioCtx.currentTime + i * 0.15;
        gain.gain.setValueAtTime(0.3, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 1.2);
        osc.start(t); osc.stop(t + 1.2);
      });
    } catch(e) {}
  }

  function speakTicket(numero, salle) {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const msg  = new SpeechSynthesisUtterance(`Ticket ${numero}, veuillez vous rendre au ${salle}`);
    msg.lang   = 'fr-FR'; msg.rate = 0.85; msg.pitch = 1;
    setTimeout(() => window.speechSynthesis.speak(msg), 600);
  }

  async function pollKiosque() {
    try {
      const res  = await fetch(`${HC.appUrl}/api/kiosque.php`);
      const data = await res.json();

      if (data.current) {
        const t = data.current;
        document.getElementById('kiosk-num').textContent   = t.numero_ticket;
        document.getElementById('kiosk-salle').textContent = t.salle_appelee ? `→ ${t.salle_appelee}` : '→ Accueil';

        if (lastTicketId !== t.id) {
          lastTicketId = t.id;
          playGong();
          speakTicket(t.numero_ticket, t.salle_appelee || 'l\'accueil');
          const panel = document.getElementById('kiosk-current');
          panel.classList.add('flash');
          setTimeout(() => panel.classList.remove('flash'), 2000);
        }
      }

      if (data.history) {
        const listEl = document.getElementById('kiosk-list');
        listEl.innerHTML = data.history.map(t => `
          <div class="ticket-list-item">
            <span class="t-num">${t.numero_ticket}</span>
            <span class="t-salle">${t.salle_appelee || ''}</span>
          </div>`).join('');
      }
    } catch(e) {}
    setTimeout(pollKiosque, 5000);
  }

  pollKiosque();
});

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
    document.getElementById('fs-icon').className = 'bi bi-fullscreen-exit';
  } else {
    document.exitFullscreen();
    document.getElementById('fs-icon').className = 'bi bi-fullscreen';
  }
}
</script>
</body>
</html>
