<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAuth(['secretaire']);

$user = currentUser();
$db   = getDB();

$error   = '';
$success = '';
$patient = null; // patient pré-chargé si recherche

// Pré-chargement patient existant
if (isset($_GET['patient_id'])) {
    $stmt = $db->prepare('SELECT * FROM patients WHERE id=?');
    $stmt->execute([(int)$_GET['patient_id']]);
    $patient = $stmt->fetch();
}

// Liste services actifs
$services = $db->query('SELECT * FROM services WHERE actif=1 ORDER BY nom_service')->fetchAll();

// Liste médecins
$medecins = $db->query("SELECT id, nom_complet, service_id FROM users WHERE role='medecin' AND actif=1 ORDER BY nom_complet")->fetchAll();

// Motifs prédéfinis
$motifs = ['Consultation générale','Bilan de santé','Radiographie','Analyse de sang','Suivi post-opératoire',
           'Vaccination','Urgence','Renouvellement d\'ordonnance','Autre'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Erreur de sécurité.';
    } else {
        $action = $_POST['action'] ?? '';

        // ── Créer / Mettre à jour patient + créer ticket ──────────────────────
        if ($action === 'enregistrer') {
            $nom       = trim($_POST['nom'] ?? '');
            $prenom    = trim($_POST['prenom'] ?? '');
            $email     = trim($_POST['email'] ?? '');
            $dob       = trim($_POST['date_naissance'] ?? '');
            $tel       = trim($_POST['telephone'] ?? '');
            $serviceId = (int)($_POST['service_id'] ?? 0);
            $medecinId = ($_POST['medecin_id'] ?? '') ?: null;
            $motif     = trim($_POST['motif_visite'] ?? '');
            $priorite  = $_POST['niveau_priorite'] ?? 'standard';
            $patientId = (int)($_POST['patient_id'] ?? 0);

            // Validation
            $errs = [];
            if (strlen($nom) < 2)              $errs[] = 'Nom invalide (min 2 caractères)';
            if (strlen($prenom) < 2)           $errs[] = 'Prénom invalide (min 2 caractères)';
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errs[] = 'Email invalide';
            if (!strtotime($dob))              $errs[] = 'Date de naissance invalide';
            if (!$serviceId)                   $errs[] = 'Veuillez sélectionner un service';
            if (!in_array($priorite, ['standard','prioritaire','urgence'])) $errs[] = 'Priorité invalide';

            if ($errs) {
                $error = implode('<br>', $errs);
            } else {
                try {
                    $db->beginTransaction();

                    if ($patientId) {
                        // Mise à jour patient existant
                        $db->prepare('UPDATE patients SET nom=?,prenom=?,email=?,date_naissance=?,telephone=?,modifie_le=NOW() WHERE id=?')
                           ->execute([$nom, $prenom, $email, $dob, $tel ?: null, $patientId]);
                        auditLog('MODIF_PATIENT', $patientId, 'patients');
                    } else {
                        // Nouveau patient
                        $ipp = generateIPP();
                        $db->prepare('INSERT INTO patients (ipp,nom,prenom,email,date_naissance,telephone) VALUES (?,?,?,?,?,?)')
                           ->execute([$ipp, $nom, $prenom, $email, $dob, $tel ?: null]);
                        $patientId = $db->lastInsertId();
                        auditLog('CREATION_PATIENT', $patientId, 'patients');
                    }

                    // Création ticket
                    $numero = generateTicketNumber($serviceId);
                    $db->prepare("INSERT INTO tickets (patient_id,service_id,medecin_id,secretaire_id,numero_ticket,niveau_priorite,motif_visite,statut_examen)
                                  VALUES (?,?,?,?,?,?,?,?)")
                       ->execute([$patientId, $serviceId, $medecinId, $user['id'], $numero, $priorite, $motif ?: null,
                                  in_array($motif, ['Radiographie','Analyse de sang']) ? 'en_cours' : 'aucun']);
                    $ticketId = $db->lastInsertId();
                    auditLog('CREATION_TICKET', $ticketId, 'tickets', ['numero' => $numero, 'patient_id' => $patientId]);

                    $db->commit();

                    // Récup nom service pour email
                    $svcName = '';
                    foreach ($services as $s) { if ($s['id'] == $serviceId) { $svcName = $s['nom_service']; break; } }

                    // Estimation attente
                    $stmtW = $db->prepare("SELECT COUNT(*) FROM tickets WHERE service_id=? AND statut_ticket='en_attente' AND id!=?");
                    $stmtW->execute([$serviceId, $ticketId]);
                    $waitEst = max(5, (int)($stmtW->fetchColumn()) * 8);

                    // Email confirmation arrivée
                    $body = emailTemplateArrivee("$prenom $nom", $svcName, $numero, date('H:i'), $waitEst);
                    sendEmail($email, APP_ETABLISSEMENT . ' - Confirmation de votre arrivée', $body, $ticketId, $patientId, 'arrivee');

                    $success = "✅ Ticket <strong>$numero</strong> créé pour <strong>$prenom $nom</strong>. Email de confirmation envoyé.";
                    $patient = null; // Reset formulaire

                } catch (Exception $e) {
                    $db->rollBack();
                    $error = 'Erreur lors de l\'enregistrement : ' . $e->getMessage();
                }
            }
        }
    }
}

$csrfToken = generateCsrfToken();
$pageTitle = 'Nouveau Patient';
require_once INCLUDES_PATH . '/header.php';
?>
<meta name="csrf-token" content="<?= $csrfToken ?>">
<meta name="app-url" content="<?= APP_URL ?>">

<div class="d-flex align-items-center gap-2 mb-4">
  <a href="<?= APP_URL ?>/modules/secretariat/dashboard.php" class="btn btn-sm btn-outline-secondary">
    <i class="bi bi-arrow-left"></i>
  </a>
  <h4 class="mb-0 fw-bold" style="color:var(--hc-blue-dark)">
    <i class="bi bi-person-plus me-2"></i>Enregistrement Patient
  </h4>
</div>

<?php if ($error): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>
<?php if ($success): ?>
<div class="alert alert-success"><?= $success ?></div>
<?php endif; ?>

<!-- Recherche patient existant -->
<div class="hc-card mb-3">
  <div class="hc-card-header">
    <div class="icon"><i class="bi bi-search"></i></div>
    <h5>Recherche patient existant</h5>
  </div>
  <div class="row g-2 align-items-end">
    <div class="col-md-8">
      <label class="form-label">Rechercher (Nom, Prénom, IPP...)</label>
      <div class="dropdown position-relative">
        <input type="text" class="form-control" id="search-patient" placeholder="Tapez au moins 3 caractères..." autocomplete="off">
        <ul class="dropdown-menu w-100" id="search-results" style="max-height:240px;overflow-y:auto"></ul>
      </div>
    </div>
    <div class="col-md-4">
      <button type="button" class="btn btn-outline-secondary w-100" onclick="resetForm()">
        <i class="bi bi-plus-circle me-1"></i>Nouveau patient (formulaire vide)
      </button>
    </div>
  </div>
</div>

<!-- Formulaire -->
<form method="POST" id="form-patient" novalidate>
  <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
  <input type="hidden" name="action" value="enregistrer">
  <input type="hidden" name="patient_id" id="f-patient-id" value="<?= (int)($patient['id'] ?? 0) ?>">

  <div class="row g-3">
    <!-- Fiche patient -->
    <div class="col-lg-6">
      <div class="hc-card">
        <div class="hc-card-header">
          <div class="icon"><i class="bi bi-person-vcard"></i></div>
          <h5>Informations Patient</h5>
          <?php if ($patient): ?>
          <span class="badge bg-info ms-auto">IPP : <?= sanitize($patient['ipp']) ?></span>
          <?php endif; ?>
        </div>
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Nom <span class="text-danger">*</span></label>
            <input type="text" class="form-control" name="nom" id="f-nom"
                   value="<?= sanitize($patient['nom'] ?? '') ?>" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">Prénom <span class="text-danger">*</span></label>
            <input type="text" class="form-control" name="prenom" id="f-prenom"
                   value="<?= sanitize($patient['prenom'] ?? '') ?>" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">Date de naissance <span class="text-danger">*</span></label>
            <input type="date" class="form-control" name="date_naissance" id="f-dob"
                   value="<?= sanitize($patient['date_naissance'] ?? '') ?>" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">Téléphone</label>
            <input type="tel" class="form-control" name="telephone" id="f-tel"
                   value="<?= sanitize($patient['telephone'] ?? '') ?>" placeholder="+237 6xx xxx xxx">
          </div>
          <div class="col-12">
            <label class="form-label">Email <span class="text-danger">*</span></label>
            <input type="email" class="form-control" name="email" id="f-email"
                   value="<?= sanitize($patient['email'] ?? '') ?>"
                   placeholder="patient@email.com" required>
            <div class="form-text"><i class="bi bi-info-circle me-1"></i>Un email de confirmation sera envoyé à cette adresse.</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Orientation & Ticket -->
    <div class="col-lg-6">
      <div class="hc-card">
        <div class="hc-card-header">
          <div class="icon"><i class="bi bi-signpost-2"></i></div>
          <h5>Orientation & Ticket</h5>
        </div>
        <div class="row g-3">
          <div class="col-12">
            <label class="form-label">Service <span class="text-danger">*</span></label>
            <select class="form-select" name="service_id" id="f-service" required onchange="filterMedecins()">
              <option value="">-- Sélectionner un service --</option>
              <?php foreach ($services as $s): ?>
              <option value="<?= $s['id'] ?>" <?= ($user['service_id'] == $s['id']) ? 'selected' : '' ?>>
                <?= sanitize($s['nom_service']) ?> (<?= sanitize($s['code_prefixe']) ?>)
              </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-12">
            <label class="form-label">Médecin (optionnel)</label>
            <select class="form-select" name="medecin_id" id="f-medecin">
              <option value="">-- Aucun médecin assigné --</option>
              <?php foreach ($medecins as $m): ?>
              <option value="<?= $m['id'] ?>" data-service="<?= $m['service_id'] ?>">
                <?= sanitize($m['nom_complet']) ?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-12">
            <label class="form-label">Motif de visite</label>
            <select class="form-select" name="motif_visite" id="f-motif">
              <option value="">-- Sélectionner un motif --</option>
              <?php foreach ($motifs as $m): ?>
              <option value="<?= sanitize($m) ?>"><?= sanitize($m) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-12">
            <label class="form-label">Niveau de priorité <span class="text-danger">*</span></label>
            <div class="d-flex gap-2 flex-wrap">
              <?php foreach ([
                ['standard','Standard','success','check-circle-fill'],
                ['prioritaire','Prioritaire','warning','arrow-up-circle-fill'],
                ['urgence','Urgence','danger','exclamation-triangle-fill'],
              ] as [$val,$lab,$col,$icon]): ?>
              <div class="form-check form-check-inline p-0">
                <input class="btn-check" type="radio" name="niveau_priorite"
                       id="prio-<?= $val ?>" value="<?= $val ?>"
                       <?= $val === 'standard' ? 'checked' : '' ?>>
                <label class="btn btn-outline-<?= $col ?>" for="prio-<?= $val ?>">
                  <i class="bi bi-<?= $icon ?> me-1"></i><?= $lab ?>
                </label>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>

      <!-- Résumé & Validation -->
      <div class="hc-card">
        <div class="hc-card-header">
          <div class="icon" style="background:#d1fae5;color:#065f46"><i class="bi bi-check-lg"></i></div>
          <h5>Validation</h5>
        </div>
        <div class="alert alert-info py-2 small mb-3">
          <i class="bi bi-envelope me-1"></i>
          Un email de confirmation avec le numéro de ticket sera automatiquement envoyé au patient.
        </div>
        <button type="submit" class="btn btn-hc-primary w-100 btn-lg">
          <i class="bi bi-ticket-perforated me-2"></i>Enregistrer et Générer le Ticket
        </button>
      </div>
    </div>
  </div>
</form>

<script>
// Recherche patient auto-complete
initPatientSearch('search-patient', 'search-results', function(p) {
  document.getElementById('f-patient-id').value = p.id;
  document.getElementById('f-nom').value         = p.nom;
  document.getElementById('f-prenom').value      = p.prenom;
  document.getElementById('f-dob').value         = p.date_naissance;
  document.getElementById('f-email').value       = p.email;
  document.getElementById('f-tel').value         = p.telephone || '';
  showToast('Patient chargé : ' + p.nom + ' ' + p.prenom, 'info');
});

function resetForm() {
  ['f-patient-id','f-nom','f-prenom','f-dob','f-email','f-tel'].forEach(id => {
    document.getElementById(id).value = '';
  });
  document.getElementById('search-patient').value = '';
  document.getElementById('prio-standard').checked = true;
}

function filterMedecins() {
  const serviceId = document.getElementById('f-service').value;
  const sel = document.getElementById('f-medecin');
  Array.from(sel.options).forEach(opt => {
    if (!opt.value) return;
    opt.hidden = opt.dataset.service && opt.dataset.service !== serviceId;
  });
  sel.value = '';
}
filterMedecins();
</script>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
