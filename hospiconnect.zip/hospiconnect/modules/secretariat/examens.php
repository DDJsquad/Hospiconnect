<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAuth(['secretaire']);
$user = currentUser();
$db   = getDB();

$serviceId = $user['service_id'];

$stmt = $db->prepare("
    SELECT t.id, t.numero_ticket, t.statut_examen, t.cree_le,
           p.nom, p.prenom, p.email
    FROM tickets t
    JOIN patients p ON p.id = t.patient_id
    WHERE t.service_id=? AND t.statut_examen IN ('en_cours','pret') AND DATE(t.cree_le)=CURDATE()
    ORDER BY t.statut_examen ASC, t.cree_le ASC
");
$stmt->execute([$serviceId]);
$examens = $stmt->fetchAll();

$pageTitle = 'Suivi des Examens';
require_once INCLUDES_PATH . '/header.php';
?>
<meta name="csrf-token" content="<?= generateCsrfToken() ?>">
<meta name="app-url" content="<?= APP_URL ?>">

<div class="d-flex align-items-center gap-2 mb-4">
  <a href="<?= APP_URL ?>/modules/secretariat/dashboard.php" class="btn btn-sm btn-outline-secondary">
    <i class="bi bi-arrow-left"></i>
  </a>
  <h4 class="mb-0 fw-bold" style="color:var(--hc-blue-dark)">
    <i class="bi bi-flask me-2"></i>Suivi des Examens — Aujourd'hui
  </h4>
</div>

<div class="hc-card">
  <div class="hc-card-header">
    <div class="icon" style="background:#fef9c3;color:#854d0e"><i class="bi bi-flask"></i></div>
    <h5>Liste des examens du jour</h5>
    <span class="badge bg-secondary ms-auto"><?= count($examens) ?> examen(s)</span>
  </div>

  <?php if (empty($examens)): ?>
  <div class="text-center text-muted py-5">
    <i class="bi bi-check-all fs-1 d-block mb-2 text-success"></i>
    Aucun examen en cours aujourd'hui.
  </div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="table table-hc table-hover mb-0">
      <thead>
        <tr><th>Ticket</th><th>Patient</th><th>Email</th><th>Heure</th><th>Statut</th><th>Action</th></tr>
      </thead>
      <tbody id="examens-table">
        <?php foreach ($examens as $ex): ?>
        <tr id="row-exam-<?= $ex['id'] ?>">
          <td><span class="fw-bold text-primary"><?= sanitize($ex['numero_ticket']) ?></span></td>
          <td class="fw-semibold"><?= sanitize($ex['nom']) ?> <?= sanitize($ex['prenom']) ?></td>
          <td><small class="text-muted"><?= sanitize($ex['email']) ?></small></td>
          <td><small><?= date('H:i', strtotime($ex['cree_le'])) ?></small></td>
          <td>
            <?php if ($ex['statut_examen'] === 'en_cours'): ?>
            <span class="badge bg-warning text-dark"><i class="bi bi-hourglass-split me-1"></i>En cours</span>
            <?php else: ?>
            <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Prêts — Email envoyé</span>
            <?php endif; ?>
          </td>
          <td>
            <?php if ($ex['statut_examen'] === 'en_cours'): ?>
            <button class="btn btn-sm btn-success btn-marquer-pret"
                    data-ticket-id="<?= $ex['id'] ?>"
                    data-nom="<?= sanitize($ex['nom'] . ' ' . $ex['prenom']) ?>"
                    data-row="row-exam-<?= $ex['id'] ?>">
              <i class="bi bi-check2-circle me-1"></i>Marquer Prêts
            </button>
            <?php else: ?>
            <span class="text-muted small"><i class="bi bi-envelope-check me-1"></i>Notifié</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<script>
document.addEventListener('click', async function(e) {
  const btn = e.target.closest('.btn-marquer-pret');
  if (!btn) return;
  const ticketId = btn.dataset.ticketId;
  const nom      = btn.dataset.nom;
  const rowId    = btn.dataset.row;
  const ok = await hcConfirm(`Marquer les examens de <strong>${nom}</strong> comme prêts ?<br>
    <small class="text-muted">Un email de notification sera envoyé automatiquement.</small>`);
  if (!ok) return;
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Envoi...';
  const res = await hcFetch('<?= APP_URL ?>/api/ticket_action.php',
    { ticket_id: ticketId, action: 'examens_prets' }, 'POST');
  if (res.success) {
    showToast('Email de notification envoyé à ' + nom, 'success');
    const row = document.getElementById(rowId);
    if (row) {
      row.cells[4].innerHTML = '<span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Prêts — Email envoyé</span>';
      row.cells[5].innerHTML = '<span class="text-muted small"><i class="bi bi-envelope-check me-1"></i>Notifié</span>';
    }
  } else {
    showToast(res.error || 'Erreur', 'danger');
    btn.disabled = false;
    btn.innerHTML = '<i class="bi bi-check2-circle me-1"></i>Marquer Prêts';
  }
});
</script>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
