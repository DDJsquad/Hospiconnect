<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAuth(['secretaire']);

$user = currentUser();
$db   = getDB();

// Stats rapides
$serviceId = $user['service_id'];

$stmtEn = $db->prepare("SELECT COUNT(*) FROM tickets WHERE service_id=? AND statut_ticket='en_attente' AND DATE(cree_le)=CURDATE()");
$stmtEn->execute([$serviceId]);
$nbAttente = $stmtEn->fetchColumn();

$stmtEx = $db->prepare("SELECT COUNT(*) FROM tickets WHERE service_id=? AND statut_examen='en_cours' AND DATE(cree_le)=CURDATE()");
$stmtEx->execute([$serviceId]);
$nbExamens = $stmtEx->fetchColumn();

$stmtAlerte = $db->prepare("SELECT COUNT(*) FROM tickets WHERE service_id=? AND statut_ticket='en_attente'
  AND TIMESTAMPDIFF(MINUTE, cree_le, NOW()) >= ?");
$stmtAlerte->execute([$serviceId, WAIT_ALERT_MINUTES]);
$nbAlertes = $stmtAlerte->fetchColumn();

$stmtTotal = $db->prepare("SELECT COUNT(*) FROM tickets WHERE service_id=? AND DATE(cree_le)=CURDATE()");
$stmtTotal->execute([$serviceId]);
$nbTotal = $stmtTotal->fetchColumn();

// Nom du service
$stmtSvc = $db->prepare('SELECT nom_service FROM services WHERE id=?');
$stmtSvc->execute([$serviceId]);
$nomService = $stmtSvc->fetchColumn() ?: 'Mon service';

$pageTitle = 'Secrétariat';
require_once INCLUDES_PATH . '/header.php';
?>
<meta name="csrf-token" content="<?= generateCsrfToken() ?>">
<meta name="polling-interval" content="<?= POLLING_INTERVAL ?>">
<meta name="app-url" content="<?= APP_URL ?>">

<!-- Titre page -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
  <div>
    <h4 class="mb-0 fw-bold" style="color:var(--hc-blue-dark)">
      <i class="bi bi-clipboard2-pulse me-2"></i>Secrétariat — <?= sanitize($nomService) ?>
    </h4>
    <small class="text-muted"><?= date('l d F Y') ?> — Bienvenue, <?= sanitize($user['nom_complet']) ?></small>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= APP_URL ?>/modules/secretariat/patient_search.php" class="btn btn-outline-primary">
      <i class="bi bi-search me-1"></i>Rechercher patient
    </a>
    <a href="<?= APP_URL ?>/modules/secretariat/patient_new.php" class="btn btn-hc-primary">
      <i class="bi bi-person-plus me-1"></i>Nouveau patient
    </a>
  </div>
</div>

<!-- KPI -->
<div class="row g-3 mb-4">
  <div class="col-6 col-xl-3">
    <div class="hc-stat">
      <div class="stat-icon" style="background:#dbeafe;color:#1A3A5C"><i class="bi bi-people-fill"></i></div>
      <div>
        <div class="stat-val text-primary"><?= $nbAttente ?></div>
        <div class="stat-lbl">En attente</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-xl-3">
    <div class="hc-stat">
      <div class="stat-icon" style="background:#fef9c3;color:#854d0e"><i class="bi bi-activity"></i></div>
      <div>
        <div class="stat-val text-warning"><?= $nbExamens ?></div>
        <div class="stat-lbl">Examens en cours</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-xl-3">
    <div class="hc-stat">
      <div class="stat-icon" style="background:#fee2e2;color:#991b1b"><i class="bi bi-exclamation-triangle-fill"></i></div>
      <div>
        <div class="stat-val text-danger"><?= $nbAlertes ?></div>
        <div class="stat-lbl">Alertes > 45 min</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-xl-3">
    <div class="hc-stat">
      <div class="stat-icon" style="background:#d1fae5;color:#065f46"><i class="bi bi-ticket-perforated-fill"></i></div>
      <div>
        <div class="stat-val text-success"><?= $nbTotal ?></div>
        <div class="stat-lbl">Total aujourd'hui</div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3">
  <!-- File d'attente en temps réel -->
  <div class="col-lg-8">
    <div class="hc-card">
      <div class="hc-card-header">
        <div class="icon"><i class="bi bi-list-ol"></i></div>
        <h5>File d'attente — <?= sanitize($nomService) ?></h5>
        <span class="badge bg-primary ms-auto" id="queue-badge">
          <i class="bi bi-arrow-repeat me-1"></i>Live
        </span>
      </div>
      <div id="queue-container">
        <div class="text-center py-4 text-muted">
          <div class="spinner-border spinner-border-sm me-2"></div>Chargement...
        </div>
      </div>
    </div>
  </div>

  <!-- Actions rapides + Examens -->
  <div class="col-lg-4">
    <!-- Actions -->
    <div class="hc-card mb-3">
      <div class="hc-card-header">
        <div class="icon"><i class="bi bi-lightning-fill"></i></div>
        <h5>Actions rapides</h5>
      </div>
      <div class="d-grid gap-2">
        <a href="<?= APP_URL ?>/modules/secretariat/patient_new.php" class="btn btn-hc-primary">
          <i class="bi bi-person-plus me-2"></i>Enregistrer un patient
        </a>
        <a href="<?= APP_URL ?>/modules/secretariat/patient_search.php" class="btn btn-outline-primary">
          <i class="bi bi-search me-2"></i>Rechercher / Éditer un patient
        </a>
        <a href="<?= APP_URL ?>/modules/secretariat/examens.php" class="btn btn-outline-warning">
          <i class="bi bi-flask me-2"></i>Gérer les examens
        </a>
      </div>
    </div>

    <!-- Examens prêts à notifier -->
    <div class="hc-card">
      <div class="hc-card-header">
        <div class="icon" style="background:#fef9c3;color:#854d0e"><i class="bi bi-flask"></i></div>
        <h5>Examens en cours</h5>
      </div>
      <?php
      $stmtEx2 = $db->prepare("
        SELECT t.id, t.numero_ticket, p.nom, p.prenom, p.email, t.cree_le
        FROM tickets t
        JOIN patients p ON p.id = t.patient_id
        WHERE t.service_id=? AND t.statut_examen='en_cours' AND DATE(t.cree_le)=CURDATE()
        ORDER BY t.cree_le ASC LIMIT 5
      ");
      $stmtEx2->execute([$serviceId]);
      $examens = $stmtEx2->fetchAll();
      ?>
      <?php if (empty($examens)): ?>
        <p class="text-muted small text-center py-2"><i class="bi bi-check-all me-1"></i>Aucun examen en attente</p>
      <?php else: ?>
        <?php foreach ($examens as $ex): ?>
        <div class="d-flex justify-content-between align-items-center border-bottom py-2">
          <div>
            <div class="fw-semibold small"><?= sanitize($ex['nom']) ?> <?= sanitize($ex['prenom']) ?></div>
            <small class="text-muted"><?= sanitize($ex['numero_ticket']) ?></small>
          </div>
          <button class="btn btn-sm btn-success btn-marquer-pret"
                  data-ticket-id="<?= $ex['id'] ?>"
                  data-nom="<?= sanitize($ex['nom'] . ' ' . $ex['prenom']) ?>">
            <i class="bi bi-check2-circle"></i> Prêts
          </button>
        </div>
        <?php endforeach; ?>
        <div class="mt-2 text-center">
          <a href="<?= APP_URL ?>/modules/secretariat/examens.php" class="btn btn-sm btn-outline-warning">Voir tout</a>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
// Polling file d'attente
startPolling('<?= APP_URL ?>/api/queue.php?service_id=<?= (int)$serviceId ?>&role=secretariat',
  'queue-container', renderQueueSecretariat);

// Marquer examens prêts
document.addEventListener('click', async function(e) {
  const btn = e.target.closest('.btn-marquer-pret');
  if (!btn) return;
  const ticketId = btn.dataset.ticketId;
  const nom      = btn.dataset.nom;
  const ok = await hcConfirm(`Marquer les examens de <strong>${nom}</strong> comme prêts ?<br><small class="text-muted">Un email sera envoyé automatiquement au patient.</small>`);
  if (!ok) return;
  const res = await hcFetch('<?= APP_URL ?>/api/ticket_action.php',
    { ticket_id: ticketId, action: 'examens_prets' }, 'POST');
  if (res.success) {
    showToast('Email envoyé au patient !', 'success');
    btn.closest('.d-flex').remove();
  } else {
    showToast(res.error || 'Erreur', 'danger');
  }
});
</script>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
