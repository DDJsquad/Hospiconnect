<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAuth(['secretaire','admin','superadmin']);
$db = getDB();

$id      = (int)($_GET['id'] ?? 0);
$error   = $success = '';

if (!$id) redirect(APP_URL . '/modules/secretariat/patient_search.php');

$stmt = $db->prepare('SELECT * FROM patients WHERE id=?');
$stmt->execute([$id]);
$patient = $stmt->fetch();
if (!$patient) redirect(APP_URL . '/modules/secretariat/patient_search.php');

// Historique visites
$stmtHist = $db->prepare("
    SELECT t.numero_ticket, t.niveau_priorite, t.statut_ticket, t.motif_visite,
           t.cree_le, t.termine_le, s.nom_service
    FROM tickets t
    JOIN services s ON s.id=t.service_id
    WHERE t.patient_id=?
    ORDER BY t.cree_le DESC LIMIT 20
");
$stmtHist->execute([$id]);
$historique = $stmtHist->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Erreur CSRF.';
    } else {
        $nom   = trim($_POST['nom'] ?? '');
        $prenom= trim($_POST['prenom'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $dob   = trim($_POST['date_naissance'] ?? '');
        $tel   = trim($_POST['telephone'] ?? '');

        if (strlen($nom)<2 || strlen($prenom)<2 || !filter_var($email, FILTER_VALIDATE_EMAIL) || !strtotime($dob)) {
            $error = 'Données invalides. Vérifiez tous les champs obligatoires.';
        } else {
            $db->prepare('UPDATE patients SET nom=?,prenom=?,email=?,date_naissance=?,telephone=? WHERE id=?')
               ->execute([$nom, $prenom, $email, $dob, $tel ?: null, $id]);
            auditLog('MODIF_PATIENT', $id, 'patients');
            $success = 'Fiche patient mise à jour avec succès.';
            // Recharger
            $stmt->execute([$id]);
            $patient = $stmt->fetch();
        }
    }
}

$csrfToken = generateCsrfToken();
$pageTitle = 'Édition Patient';
require_once INCLUDES_PATH . '/header.php';
?>
<div class="d-flex align-items-center gap-2 mb-4">
  <a href="<?= APP_URL ?>/modules/secretariat/patient_search.php" class="btn btn-sm btn-outline-secondary">
    <i class="bi bi-arrow-left"></i>
  </a>
  <h4 class="mb-0 fw-bold" style="color:var(--hc-blue-dark)">
    <i class="bi bi-person-vcard me-2"></i>Fiche Patient
  </h4>
  <span class="badge bg-info ms-2">IPP : <?= sanitize($patient['ipp']) ?></span>
  <a href="<?= APP_URL ?>/modules/secretariat/patient_new.php?patient_id=<?= $id ?>" class="btn btn-hc-primary ms-auto">
    <i class="bi bi-ticket-perforated me-1"></i>Nouvelle visite
  </a>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>

<div class="row g-3">
  <!-- Formulaire édition -->
  <div class="col-lg-5">
    <div class="hc-card">
      <div class="hc-card-header">
        <div class="icon"><i class="bi bi-pencil"></i></div>
        <h5>Informations personnelles</h5>
      </div>
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
        <div class="row g-3">
          <div class="col-6">
            <label class="form-label">Nom *</label>
            <input type="text" class="form-control" name="nom" value="<?= sanitize($patient['nom']) ?>" required>
          </div>
          <div class="col-6">
            <label class="form-label">Prénom *</label>
            <input type="text" class="form-control" name="prenom" value="<?= sanitize($patient['prenom']) ?>" required>
          </div>
          <div class="col-6">
            <label class="form-label">Date de naissance *</label>
            <input type="date" class="form-control" name="date_naissance" value="<?= sanitize($patient['date_naissance']) ?>" required>
          </div>
          <div class="col-6">
            <label class="form-label">Téléphone</label>
            <input type="tel" class="form-control" name="telephone" value="<?= sanitize($patient['telephone'] ?? '') ?>">
          </div>
          <div class="col-12">
            <label class="form-label">Email *</label>
            <input type="email" class="form-control" name="email" value="<?= sanitize($patient['email']) ?>" required>
          </div>
          <div class="col-12">
            <button type="submit" class="btn btn-hc-primary w-100">
              <i class="bi bi-save me-2"></i>Enregistrer les modifications
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <!-- Historique visites -->
  <div class="col-lg-7">
    <div class="hc-card">
      <div class="hc-card-header">
        <div class="icon"><i class="bi bi-clock-history"></i></div>
        <h5>Historique des visites</h5>
        <span class="badge bg-secondary ms-auto"><?= count($historique) ?></span>
      </div>
      <?php if (empty($historique)): ?>
      <p class="text-muted text-center py-3">Aucune visite enregistrée.</p>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table table-sm table-hover mb-0">
          <thead class="table-light">
            <tr><th>Ticket</th><th>Service</th><th>Motif</th><th>Priorité</th><th>Date</th><th>Statut</th></tr>
          </thead>
          <tbody>
            <?php foreach ($historique as $h): ?>
            <tr>
              <td><code class="text-primary"><?= sanitize($h['numero_ticket']) ?></code></td>
              <td><small><?= sanitize($h['nom_service']) ?></small></td>
              <td><small><?= sanitize($h['motif_visite'] ?? '-') ?></small></td>
              <td><?= priorityBadge($h['niveau_priorite']) ?></td>
              <td><small class="text-muted"><?= date('d/m/Y H:i', strtotime($h['cree_le'])) ?></small></td>
              <td>
                <?php $statCols = ['en_attente'=>'warning','appele'=>'info','termine'=>'success','absent'=>'secondary']; ?>
                <span class="badge bg-<?= $statCols[$h['statut_ticket']] ?? 'secondary' ?>" style="font-size:10px">
                  <?= str_replace('_',' ', strtoupper($h['statut_ticket'])) ?>
                </span>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
