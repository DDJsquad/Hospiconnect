<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAuth(['secretaire']);
$db = getDB();

$q        = trim($_GET['q'] ?? '');
$patients = [];

if (strlen($q) >= 2) {
    $like = "%$q%";
    $stmt = $db->prepare("
        SELECT p.*, 
               COUNT(t.id) as nb_tickets,
               MAX(t.cree_le) as derniere_visite
        FROM patients p
        LEFT JOIN tickets t ON t.patient_id = p.id
        WHERE p.nom LIKE ? OR p.prenom LIKE ? OR p.ipp LIKE ? OR p.email LIKE ?
        GROUP BY p.id
        ORDER BY p.nom, p.prenom
        LIMIT 30
    ");
    $stmt->execute([$like, $like, $like, $like]);
    $patients = $stmt->fetchAll();
}

$pageTitle = 'Recherche Patient';
require_once INCLUDES_PATH . '/header.php';
?>
<meta name="app-url" content="<?= APP_URL ?>">

<div class="d-flex align-items-center gap-2 mb-4">
  <a href="<?= APP_URL ?>/modules/secretariat/dashboard.php" class="btn btn-sm btn-outline-secondary">
    <i class="bi bi-arrow-left"></i>
  </a>
  <h4 class="mb-0 fw-bold" style="color:var(--hc-blue-dark)">
    <i class="bi bi-search me-2"></i>Recherche Patient
  </h4>
</div>

<div class="hc-card mb-4">
  <form method="GET" class="row g-2 align-items-end">
    <div class="col-md-8">
      <label class="form-label">Recherche (Nom, Prénom, IPP, Email)</label>
      <input type="text" class="form-control form-control-lg" name="q"
             value="<?= sanitize($q) ?>" placeholder="Tapez votre recherche..."
             autofocus minlength="2">
    </div>
    <div class="col-md-2">
      <button type="submit" class="btn btn-hc-primary w-100 btn-lg">
        <i class="bi bi-search me-1"></i>Rechercher
      </button>
    </div>
    <div class="col-md-2">
      <a href="<?= APP_URL ?>/modules/secretariat/patient_new.php" class="btn btn-outline-success w-100 btn-lg">
        <i class="bi bi-person-plus me-1"></i>Nouveau
      </a>
    </div>
  </form>
</div>

<?php if ($q && empty($patients)): ?>
<div class="alert alert-warning">
  <i class="bi bi-exclamation-circle me-2"></i>Aucun patient trouvé pour "<strong><?= sanitize($q) ?></strong>".
  <a href="<?= APP_URL ?>/modules/secretariat/patient_new.php" class="alert-link ms-2">Créer un nouveau patient ?</a>
</div>
<?php elseif (!empty($patients)): ?>
<div class="hc-card">
  <div class="hc-card-header">
    <div class="icon"><i class="bi bi-people"></i></div>
    <h5><?= count($patients) ?> patient(s) trouvé(s)</h5>
  </div>
  <div class="table-responsive">
    <table class="table table-hc table-hover mb-0">
      <thead>
        <tr>
          <th>IPP</th><th>Nom & Prénom</th><th>Date de naissance</th>
          <th>Email</th><th>Téléphone</th><th>Visites</th><th>Dernière visite</th><th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($patients as $p): ?>
        <tr>
          <td><code class="text-primary"><?= sanitize($p['ipp']) ?></code></td>
          <td class="fw-semibold"><?= sanitize($p['nom']) ?> <?= sanitize($p['prenom']) ?></td>
          <td><?= sanitize($p['date_naissance']) ?></td>
          <td><small><?= sanitize($p['email']) ?></small></td>
          <td><small><?= sanitize($p['telephone'] ?? '-') ?></small></td>
          <td><span class="badge bg-secondary"><?= $p['nb_tickets'] ?></span></td>
          <td><small class="text-muted"><?= $p['derniere_visite'] ? date('d/m/Y', strtotime($p['derniere_visite'])) : '-' ?></small></td>
          <td>
            <div class="d-flex gap-1">
              <a href="<?= APP_URL ?>/modules/secretariat/patient_new.php?patient_id=<?= $p['id'] ?>"
                 class="btn btn-sm btn-primary" title="Enregistrer une visite">
                <i class="bi bi-ticket-perforated"></i>
              </a>
              <a href="<?= APP_URL ?>/modules/secretariat/patient_edit.php?id=<?= $p['id'] ?>"
                 class="btn btn-sm btn-outline-secondary" title="Éditer la fiche">
                <i class="bi bi-pencil"></i>
              </a>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php elseif (!$q): ?>
<div class="text-center text-muted py-5">
  <i class="bi bi-search fs-1 d-block mb-2"></i>
  Entrez un nom, prénom, IPP ou email pour rechercher un patient.
</div>
<?php endif; ?>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
