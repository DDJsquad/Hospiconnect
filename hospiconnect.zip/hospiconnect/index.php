<?php
/**
 * HospiConnect - Page de connexion
 * Clinique du Chatelet
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

// Déjà connecté → redirection
if (isLoggedIn()) {
    $role = $_SESSION['role'];
    if (in_array($role, ['superadmin', 'admin'])) redirect(APP_URL . '/modules/admin/dashboard.php');
    elseif ($role === 'secretaire')               redirect(APP_URL . '/modules/secretariat/dashboard.php');
    elseif ($role === 'medecin')                  redirect(APP_URL . '/modules/medecin/dashboard.php');
}

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérif CSRF
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Erreur de sécurité. Veuillez recharger la page.';
    } else {
        $login = trim($_POST['login'] ?? '');
        $mdp   = $_POST['password'] ?? '';

        if (empty($login) || empty($mdp)) {
            $error = 'Veuillez remplir tous les champs.';
        } else {
            $db = getDB();
            $stmt = $db->prepare('SELECT * FROM users WHERE login = ? AND actif = 1 LIMIT 1');
            $stmt->execute([$login]);
            $user = $stmt->fetch();

            if ($user) {
                // Vérif blocage
                if ($user['bloque_jusqu'] && strtotime($user['bloque_jusqu']) > time()) {
                    $restant = ceil((strtotime($user['bloque_jusqu']) - time()) / 60);
                    $error = "Compte temporairement bloqué. Réessayez dans {$restant} minute(s).";
                    auditLog('CONNEXION_ECHEC_BLOQUE', $user['id'], 'users');
                } elseif (password_verify($mdp, $user['password'])) {
                    // Succès
                    session_regenerate_id(true);
                    $_SESSION['user_id']      = $user['id'];
                    $_SESSION['login']        = $user['login'];
                    $_SESSION['role']         = $user['role'];
                    $_SESSION['nom_complet']  = $user['nom_complet'];
                    $_SESSION['service_id']   = $user['service_id'];
                    $_SESSION['last_activity']= time();

                    // Reset tentatives
                    $db->prepare('UPDATE users SET tentatives_echec=0, bloque_jusqu=NULL, derniere_connexion=NOW() WHERE id=?')
                       ->execute([$user['id']]);

                    auditLog('CONNEXION_SUCCES', $user['id'], 'users');

                    // Redirection selon rôle
                    if (in_array($user['role'], ['superadmin', 'admin'])) redirect(APP_URL . '/modules/admin/dashboard.php');
                    elseif ($user['role'] === 'secretaire')               redirect(APP_URL . '/modules/secretariat/dashboard.php');
                    elseif ($user['role'] === 'medecin')                  redirect(APP_URL . '/modules/medecin/dashboard.php');
                    else redirect(APP_URL . '/index.php');
                } else {
                    // Mauvais MDP
                    $tentatives = $user['tentatives_echec'] + 1;
                    if ($tentatives >= MAX_LOGIN_ATTEMPTS) {
                        $bloqueJusqu = date('Y-m-d H:i:s', time() + LOCKOUT_DURATION);
                        $db->prepare('UPDATE users SET tentatives_echec=?, bloque_jusqu=? WHERE id=?')
                           ->execute([$tentatives, $bloqueJusqu, $user['id']]);
                        $error = 'Trop de tentatives échouées. Compte bloqué 15 minutes.';
                        auditLog('CONNEXION_ECHEC_BLOCAGE', $user['id'], 'users', ['tentatives' => $tentatives]);
                    } else {
                        $restant = MAX_LOGIN_ATTEMPTS - $tentatives;
                        $db->prepare('UPDATE users SET tentatives_echec=? WHERE id=?')
                           ->execute([$tentatives, $user['id']]);
                        $error = "Identifiants incorrects. Encore {$restant} tentative(s) avant blocage.";
                        auditLog('CONNEXION_ECHEC', $user['id'], 'users', ['tentatives' => $tentatives]);
                    }
                }
            } else {
                $error = 'Identifiants incorrects.';
                auditLog('CONNEXION_ECHEC_INCONNU', null, 'users', ['login_tente' => $login]);
            }
        }
    }
}

if (isset($_GET['error']) && $_GET['error'] === 'acces_refuse') {
    $error = 'Accès refusé. Vous n\'avez pas les permissions nécessaires.';
}
if (isset($_GET['logout'])) {
    $success = 'Vous avez été déconnecté avec succès.';
}

$csrfToken = generateCsrfToken();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Connexion — <?= APP_ETABLISSEMENT ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/hospiconnect.css">
</head>
<body>

<div class="hc-login-wrapper">
  <div class="hc-login-card">

    <!-- En-tête -->
    <div class="hc-login-header">
      <img src="<?= APP_URL ?>/assets/img/logo_clinique.png" alt="Logo Clinique du Chatelet">
      <h1><?= APP_ETABLISSEMENT ?></h1>
      <p><?= APP_NAME ?> — Accès Personnel</p>
    </div>

    <!-- Corps -->
    <div class="hc-login-body">

      <?php if ($error): ?>
      <div class="alert alert-danger d-flex align-items-center gap-2 py-2 mb-3" role="alert">
        <i class="bi bi-exclamation-triangle-fill flex-shrink-0"></i>
        <div><?= sanitize($error) ?></div>
      </div>
      <?php endif; ?>

      <?php if ($success): ?>
      <div class="alert alert-success d-flex align-items-center gap-2 py-2 mb-3">
        <i class="bi bi-check-circle-fill flex-shrink-0"></i>
        <div><?= sanitize($success) ?></div>
      </div>
      <?php endif; ?>

      <form method="POST" action="" autocomplete="off" novalidate>
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <div class="mb-3">
          <label class="form-label" for="login">
            <i class="bi bi-person me-1"></i>Identifiant
          </label>
          <input type="text" class="form-control form-control-lg" id="login" name="login"
                 placeholder="Votre login" value="<?= sanitize($_POST['login'] ?? '') ?>"
                 required autofocus>
        </div>

        <div class="mb-4">
          <label class="form-label" for="password">
            <i class="bi bi-lock me-1"></i>Mot de passe
          </label>
          <div class="input-group">
            <input type="password" class="form-control form-control-lg" id="password"
                   name="password" placeholder="Votre mot de passe" required>
            <button class="btn btn-outline-secondary" type="button" id="toggle-pwd" tabindex="-1">
              <i class="bi bi-eye" id="toggle-pwd-icon"></i>
            </button>
          </div>
        </div>

        <button type="submit" class="btn btn-hc-primary w-100 btn-lg">
          <i class="bi bi-box-arrow-in-right me-2"></i>Se connecter
        </button>
      </form>

      <hr class="my-4">
      <div class="text-center">
        <a href="<?= APP_URL ?>/modules/auth/forgot_password.php" class="text-muted small">
          <i class="bi bi-key me-1"></i>Mot de passe oublié ?
        </a>
      </div>

      <!-- Lien écran salle (public) -->
      <div class="text-center mt-2">
        <a href="<?= APP_URL ?>/modules/affichage/salle.php" class="text-muted small" target="_blank">
          <i class="bi bi-display me-1"></i>Écran salle d'attente
        </a>
      </div>
<!-- Copyright dynamique -->
      <div class="text-center mt-4 pt-3" style="border-top: 1px solid #e9ecef;">
        <small class="text-muted">
          &copy; 2025–<?= date('Y') ?> 
          <strong style="color:var(--hc-blue-dark)"></strong>
          &bull; Propulsé par 
          <a href="https://wa.me/+237671384110" target="_blank" 
             style="color:var(--hc-blue-med);text-decoration:none;font-weight:600">
            junior DJOUAKEP
          </a>
          <br>
          <span style="font-size:10px;opacity:.6">HospiConnect v<?= APP_VERSION ?> — Tous droits réservés</span>
        </small>
      </div>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Toggle affichage mot de passe
document.getElementById('toggle-pwd').addEventListener('click', function() {
  const input = document.getElementById('password');
  const icon  = document.getElementById('toggle-pwd-icon');
  if (input.type === 'password') {
    input.type = 'text';
    icon.className = 'bi bi-eye-slash';
  } else {
    input.type = 'password';
    icon.className = 'bi bi-eye';
  }
});
</script>
</body>
</html>
