/**
 * HospiConnect - JavaScript principal
 * Clinique du Chatelet
 */

'use strict';

// ─── CSRF Token global ───────────────────────────────────────────────────────
const HC = {
  csrfToken: document.querySelector('meta[name="csrf-token"]')?.content || '',
  pollingInterval: parseInt(document.querySelector('meta[name="polling-interval"]')?.content || '15000'),
  appUrl: document.querySelector('meta[name="app-url"]')?.content || '',
};

// ─── Utilitaires AJAX ────────────────────────────────────────────────────────
async function hcFetch(url, data = null, method = 'GET') {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
  };
  if (data) {
    opts.body = JSON.stringify({ ...data, csrf_token: HC.csrfToken });
  }
  try {
    const res = await fetch(url, opts);
    return await res.json();
  } catch (e) {
    console.error('[HospiConnect] Erreur fetch:', e);
    return { success: false, error: 'Erreur réseau' };
  }
}

// ─── Toast notifications ─────────────────────────────────────────────────────
function showToast(msg, type = 'success') {
  let container = document.getElementById('hc-toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'hc-toast-container';
    container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
    container.style.zIndex = 9999;
    document.body.appendChild(container);
  }
  const icons = { success: 'check-circle-fill', danger: 'x-circle-fill', warning: 'exclamation-triangle-fill', info: 'info-circle-fill' };
  const id = 'toast-' + Date.now();
  const html = `
    <div id="${id}" class="toast align-items-center text-bg-${type} border-0" role="alert" aria-live="assertive">
      <div class="d-flex">
        <div class="toast-body">
          <i class="bi bi-${icons[type] || 'info-circle-fill'} me-2"></i>${msg}
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
    </div>`;
  container.insertAdjacentHTML('beforeend', html);
  const toastEl = document.getElementById(id);
  const toast = new bootstrap.Toast(toastEl, { delay: 4000 });
  toast.show();
  toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
}

// ─── Confirmation dialog ─────────────────────────────────────────────────────
function hcConfirm(msg) {
  return new Promise(resolve => {
    let modal = document.getElementById('hc-confirm-modal');
    if (!modal) {
      document.body.insertAdjacentHTML('beforeend', `
        <div class="modal fade" id="hc-confirm-modal" tabindex="-1">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header bg-warning">
                <h5 class="modal-title"><i class="bi bi-exclamation-triangle me-2"></i>Confirmation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body" id="hc-confirm-msg"></div>
              <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal" id="hc-confirm-no">Annuler</button>
                <button class="btn btn-danger" id="hc-confirm-yes">Confirmer</button>
              </div>
            </div>
          </div>
        </div>`);
      modal = document.getElementById('hc-confirm-modal');
    }
    document.getElementById('hc-confirm-msg').innerHTML = msg;
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
    document.getElementById('hc-confirm-yes').onclick = () => { bsModal.hide(); resolve(true); };
    document.getElementById('hc-confirm-no').onclick  = () => { bsModal.hide(); resolve(false); };
    modal.addEventListener('hidden.bs.modal', () => resolve(false), { once: true });
  });
}

// ─── Recherche patient (auto-complétion) ─────────────────────────────────────
function initPatientSearch(inputId, resultsId, onSelect) {
  const input   = document.getElementById(inputId);
  const results = document.getElementById(resultsId);
  if (!input || !results) return;

  let timer;
  input.addEventListener('input', () => {
    clearTimeout(timer);
    const q = input.value.trim();
    if (q.length < 3) { results.innerHTML = ''; results.classList.remove('show'); return; }
    timer = setTimeout(async () => {
      const data = await hcFetch(`${HC.appUrl}/api/patient_search.php?q=${encodeURIComponent(q)}`);
      results.innerHTML = '';
      if (data.patients && data.patients.length > 0) {
        data.patients.forEach(p => {
          const item = document.createElement('li');
          item.className = 'dropdown-item cursor-pointer';
          item.innerHTML = `<strong>${escHtml(p.nom)} ${escHtml(p.prenom)}</strong>
            <small class="text-muted ms-2">${escHtml(p.ipp)} &bull; ${escHtml(p.date_naissance)}</small>`;
          item.addEventListener('click', () => {
            input.value = `${p.nom} ${p.prenom}`;
            results.innerHTML = '';
            results.classList.remove('show');
            if (onSelect) onSelect(p);
          });
          results.appendChild(item);
        });
        results.classList.add('show');
      } else {
        results.innerHTML = '<li class="dropdown-item text-muted"><i class="bi bi-search me-1"></i>Aucun patient trouvé</li>';
        results.classList.add('show');
      }
    }, 300);
  });

  document.addEventListener('click', e => {
    if (!input.contains(e.target) && !results.contains(e.target)) {
      results.classList.remove('show');
    }
  });
}

function escHtml(str) {
  return String(str).replace(/[&<>"']/g, m =>
    ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[m]);
}

// ─── AJAX Polling file d'attente ─────────────────────────────────────────────
let pollingTimer = null;

function startPolling(url, containerId, renderFn) {
  const container = document.getElementById(containerId);
  if (!container) return;

  async function poll() {
    const data = await hcFetch(url);
    if (data.tickets !== undefined) {
      renderFn(data, container);
    }
    pollingTimer = setTimeout(poll, HC.pollingInterval);
  }
  poll();
}

function stopPolling() {
  if (pollingTimer) { clearTimeout(pollingTimer); pollingTimer = null; }
}

// ─── Rendu file d'attente secrétariat ────────────────────────────────────────
function renderQueueSecretariat(data, container) {
  if (!data.tickets || data.tickets.length === 0) {
    container.innerHTML = `<div class="text-center text-muted py-5">
      <i class="bi bi-inbox fs-1 d-block mb-2"></i>Aucun patient en attente</div>`;
    return;
  }
  container.innerHTML = data.tickets.map(t => {
    const wait = parseInt(t.wait_minutes || 0);
    const alerte = wait >= 45 ? 'alerte-attente' : '';
    const waitClass = wait >= 45 ? 'wait-danger' : (wait >= 20 ? 'wait-warn' : 'wait-ok');
    return `
    <div class="ticket-row ${t.niveau_priorite} ${alerte}">
      <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center gap-3">
          <div class="ticket-num">${escHtml(t.numero_ticket)}</div>
          <div>
            <div class="fw-semibold">${escHtml(t.nom)} ${escHtml(t.prenom)}</div>
            <small class="text-muted">${escHtml(t.motif_visite || 'Non précisé')} &bull; ${escHtml(t.nom_service)}</small>
          </div>
        </div>
        <div class="d-flex align-items-center gap-3 flex-shrink-0">
          <div class="text-center">
            <div class="${waitClass} fw-bold">${wait} min</div>
            <small class="text-muted">attente</small>
          </div>
          <div>${priorityBadge(t.niveau_priorite)}</div>
        </div>
      </div>
    </div>`;
  }).join('');
}

function priorityBadge(p) {
  const map = {
    urgence:     '<span class="badge bg-danger">Urgence</span>',
    prioritaire: '<span class="badge bg-warning text-dark">Prioritaire</span>',
    standard:    '<span class="badge bg-success">Standard</span>',
  };
  return map[p] || '<span class="badge bg-secondary">-</span>';
}

// ─── Rendu file d'attente médecin ────────────────────────────────────────────
// function renderQueueMedecin(data, container) {
//   if (!data.tickets || data.tickets.length === 0) {
//     container.innerHTML = `<div class="text-center text-muted py-5">
//       <i class="bi bi-check-circle fs-1 d-block mb-2 text-success"></i>File d'attente vide</div>`;
//     // Update counter
//     const el = document.getElementById('queue-count');
//     if (el) el.textContent = '0';
//     return;
//   }
//   const el = document.getElementById('queue-count');
//   if (el) el.textContent = data.tickets.length;

//   container.innerHTML = data.tickets.map((t, i) => {
//     const wait = parseInt(t.wait_minutes || 0);
//     const alerte = wait >= 45 ? 'alerte-attente' : '';
//     const waitClass = wait >= 45 ? 'wait-danger' : (wait >= 20 ? 'wait-warn' : 'wait-ok');
//     return `
//     <div class="ticket-row ${t.niveau_priorite} ${alerte}" id="ticket-row-${t.id}">
//       <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
//         <div class="d-flex align-items-center gap-3">
//           <div class="text-muted fw-bold" style="min-width:24px">#${i+1}</div>
//           <div class="ticket-num">${escHtml(t.numero_ticket)}</div>
//           <div>
//             <div class="fw-semibold">${escHtml(t.nom)} ${escHtml(t.prenom)}</div>
//             <small class="text-muted">${escHtml(t.motif_visite || 'Non précisé')} &bull; ${escHtml(t.date_naissance)}</small>
//           </div>
//         </div>
//         <div class="d-flex align-items-center gap-2 flex-wrap">
//           <span class="${waitClass} fw-bold small"><i class="bi bi-clock me-1"></i>${wait} min</span>
//           ${priorityBadge(t.niveau_priorite)}
//           <button class="btn btn-sm btn-success" onclick="actionTicket(${t.id},'appeler')">
//             <i class="bi bi-megaphone me-1"></i>Appeler
//           </button>
//           <button class="btn btn-sm btn-warning" onclick="actionTicket(${t.id},'absent')">
//             <i class="bi bi-person-x me-1"></i>Absent
//           </button>
//           <button class="btn btn-sm btn-primary" onclick="ouvrirTransfert(${t.id},'${escHtml(t.numero_ticket)}')">
//             <i class="bi bi-arrow-left-right me-1"></i>Transférer
//           </button>
//           <button class="btn btn-sm btn-danger" onclick="actionTicket(${t.id},'terminer')">
//             <i class="bi bi-check2-circle me-1"></i>Clôturer
//           </button>
//         </div>
//       </div>
//     </div>`;
//   }).join('');
// }

function renderQueueMedecin(data, container) {
  if (!data.tickets || data.tickets.length === 0) {
    container.innerHTML = `<div class="text-center text-muted py-5">
      <i class="bi bi-check-circle fs-1 d-block mb-2 text-success"></i>File d'attente vide</div>`;
    const el = document.getElementById('queue-count');
    if (el) el.textContent = '0';
    return;
  }

  // Update counter
  const el = document.getElementById('queue-count');
  if (el) el.textContent = data.tickets.length;

  let html = '';
  data.tickets.forEach(function(t, i) {
    const wait = parseInt(t.wait_minutes || 0);
    const alerte = wait >= 45 ? 'alerte-attente' : '';
    const waitClass = wait >= 45 ? 'wait-danger' : (wait >= 20 ? 'wait-warn' : 'wait-ok');
    const priorite = t.niveau_priorite || 'standard';

    html += `
    <div class="ticket-row ${priorite} ${alerte}" id="ticket-row-${t.id}">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
        <div class="d-flex align-items-center gap-3">
          <div class="text-muted fw-bold" style="min-width:24px">#${i+1}</div>
          <div class="ticket-num">${t.numero_ticket}</div>
          <div>
            <div class="fw-semibold">${t.nom} ${t.prenom}</div>
            <small class="text-muted">${t.motif_visite || 'Non précisé'} &bull; ${t.date_naissance}</small>
          </div>
        </div>
        <div class="d-flex align-items-center gap-2 flex-wrap">
          <span class="${waitClass} fw-bold small">
            <i class="bi bi-clock me-1"></i>${wait} min
          </span>
          ${priorityBadge(priorite)}
          <button class="btn btn-sm btn-success" onclick="actionTicket(${t.id},'appeler')">
            <i class="bi bi-megaphone me-1"></i>Appeler
          </button>
          <button class="btn btn-sm btn-warning" onclick="actionTicket(${t.id},'absent')">
            <i class="bi bi-person-x me-1"></i>Absent
          </button>
          <button class="btn btn-sm btn-primary" onclick="ouvrirTransfert(${t.id},'${t.numero_ticket}')">
            <i class="bi bi-arrow-left-right me-1"></i>Transférer
          </button>
          <button class="btn btn-sm btn-danger" onclick="actionTicket(${t.id},'terminer')">
            <i class="bi bi-check2-circle me-1"></i>Clôturer
          </button>
        </div>
      </div>
    </div>`;
  });

  container.innerHTML = html;
}
// ─── Actions ticket (médecin) ─────────────────────────────────────────────────
async function actionTicket(ticketId, action) {
  const labels = { appeler: 'appeler ce patient ?', absent: 'marquer ce patient absent ?', terminer: 'clôturer cette consultation ?' };
  const ok = await hcConfirm(`Voulez-vous vraiment <strong>${labels[action] || action}</strong>`);
  if (!ok) return;
  const data = await hcFetch(`${HC.appUrl}/api/ticket_action.php`, { ticket_id: ticketId, action }, 'POST');
  if (data.success) {
    showToast(data.message || 'Action effectuée', 'success');
  } else {
    showToast(data.error || 'Erreur', 'danger');
  }
}

// ─── Transfert inter-services ─────────────────────────────────────────────────
async function ouvrirTransfert(ticketId, numero) {
  const data = await hcFetch(`${HC.appUrl}/api/services_list.php`);
  if (!data.services) { showToast('Impossible de charger les services', 'danger'); return; }

  const options = data.services.map(s =>
    `<option value="${s.id}">${escHtml(s.nom_service)} (${escHtml(s.code_prefixe)})</option>`
  ).join('');

  document.body.insertAdjacentHTML('beforeend', `
    <div class="modal fade" id="modal-transfert" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header bg-primary text-white">
            <h5 class="modal-title"><i class="bi bi-arrow-left-right me-2"></i>Transfert — ${escHtml(numero)}</h5>
            <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <label class="form-label">Service de destination</label>
            <select class="form-select" id="transfert-service">${options}</select>
            <label class="form-label mt-3">Motif du transfert</label>
            <input class="form-control" id="transfert-motif" placeholder="Motif (optionnel)">
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
            <button class="btn btn-primary" id="btn-transfert-ok">
              <i class="bi bi-send me-1"></i>Transférer
            </button>
          </div>
        </div>
      </div>
    </div>`);

  const modalEl = document.getElementById('modal-transfert');
  const modal = new bootstrap.Modal(modalEl);
  modal.show();

  document.getElementById('btn-transfert-ok').onclick = async () => {
    const serviceId = document.getElementById('transfert-service').value;
    const motif     = document.getElementById('transfert-motif').value;
    const res = await hcFetch(`${HC.appUrl}/api/ticket_action.php`,
      { ticket_id: ticketId, action: 'transferer', service_id: serviceId, motif }, 'POST');
    modal.hide();
    modalEl.remove();
    if (res.success) showToast(`Transféré → ${res.nouveau_ticket}`, 'success');
    else showToast(res.error || 'Erreur transfert', 'danger');
  };
  modalEl.addEventListener('hidden.bs.modal', () => modalEl.remove(), { once: true });
}

// ─── Kiosque salle d'attente ─────────────────────────────────────────────────
function initKiosque() {
  const mainEl  = document.getElementById('kiosk-current');
  const listEl  = document.getElementById('kiosk-list');
  const clockEl = document.getElementById('kiosk-clock');

  if (clockEl) {
    setInterval(() => {
      clockEl.textContent = new Date().toLocaleTimeString('fr-FR',
        { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }, 1000);
  }

  let lastTicket = null;
  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

  function playGong() {
    try {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain); gain.connect(audioCtx.destination);
      osc.type = 'sine'; osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.4, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.5);
      osc.start(); osc.stop(audioCtx.currentTime + 1.5);
    } catch(e) {}
  }

  function speakTicket(numero, salle) {
    if (!window.speechSynthesis) return;
    const msg = new SpeechSynthesisUtterance(`Ticket ${numero}, veuillez vous rendre au ${salle}`);
    msg.lang = 'fr-FR'; msg.rate = 0.9;
    window.speechSynthesis.speak(msg);
  }

  async function pollKiosque() {
    const data = await hcFetch(`${HC.appUrl}/api/kiosque.php`);
    if (data.current) {
      const t = data.current;
      if (mainEl) {
        mainEl.querySelector('.num').textContent  = t.numero_ticket;
        mainEl.querySelector('.salle').textContent = t.salle_appelee ? `→ ${t.salle_appelee}` : '';
      }
      if (lastTicket !== t.id) {
        lastTicket = t.id;
        playGong();
        speakTicket(t.numero_ticket, t.salle_appelee || 'l\'accueil');
        if (mainEl) mainEl.classList.add('flash');
        setTimeout(() => mainEl?.classList.remove('flash'), 2000);
      }
    }
    if (data.history && listEl) {
      listEl.innerHTML = (data.history || []).map(t => `
        <div class="ticket-list-item">
          <span class="t-num">${escHtml(t.numero_ticket)}</span>
          <span class="t-salle">${escHtml(t.salle_appelee || '')}</span>
        </div>`).join('');
    }
    setTimeout(pollKiosque, 5000);
  }
  pollKiosque();
}
