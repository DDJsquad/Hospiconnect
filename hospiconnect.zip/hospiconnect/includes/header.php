<?php
/**
 * HospiConnect - Header commun (inclus dans toutes les pages)
 * $pageTitle doit être défini avant l'inclusion
 */
$pageTitle = $pageTitle ?? 'HospiConnect';
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= sanitize($pageTitle) ?> — <?= APP_ETABLISSEMENT ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/hospiconnect.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark hc-navbar">
  <div class="container-fluid px-4">
    <a class="navbar-brand d-flex align-items-center gap-2" href="<?= APP_URL ?>/index.php">
      <img src="<?= APP_URL ?>/assets/img/logo_clinique.png" alt="Logo" height="38" class="rounded-circle border border-2 border-white">
      <div class="lh-1">
        <div class="fw-bold fs-6"><?= APP_ETABLISSEMENT ?></div>
        <div class="text-white-50" style="font-size:11px"><?= APP_NAME ?> v<?= APP_VERSION ?></div>
      </div>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav me-auto">
        <?php if ($user['role'] === 'secretaire'): ?>
        <li class="nav-item">
          <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'secretariat') !== false ? 'active' : '' ?>"
             href="<?= APP_URL ?>/modules/secretariat/dashboard.php">
            <i class="bi bi-clipboard2-pulse me-1"></i>Secrétariat
          </a>
        </li>
        <?php elseif ($user['role'] === 'medecin'): ?>
        <li class="nav-item">
          <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'medecin') !== false ? 'active' : '' ?>"
             href="<?= APP_URL ?>/modules/medecin/dashboard.php">
            <i class="bi bi-heart-pulse me-1"></i>File d'attente
          </a>
        </li>
        <?php elseif (in_array($user['role'], ['admin', 'superadmin'])): ?>
        <li class="nav-item">
          <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'admin') !== false ? 'active' : '' ?>"
             href="<?= APP_URL ?>/modules/admin/dashboard.php">
            <i class="bi bi-speedometer2 me-1"></i>Administration
          </a>
        </li>
        <?php endif; ?>

        <li class="nav-item">
          <a class="nav-link" href="<?= APP_URL ?>/modules/affichage/salle.php" target="_blank">
            <i class="bi bi-display me-1"></i>Écran salle
          </a>
        </li>
      </ul>

      <div class="d-flex align-items-center gap-3">
        <div class="text-white-50 small d-none d-lg-block">
          <i class="bi bi-clock me-1"></i><span id="hc-clock"></span>
        </div>
        <div class="dropdown">
          <button class="btn btn-sm btn-outline-light dropdown-toggle" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle me-1"></i><?= sanitize($user['nom_complet'] ?: $user['login']) ?>
            <span class="badge bg-primary ms-1" style="font-size:10px"><?= strtoupper($user['role']) ?></span>
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><span class="dropdown-item-text text-muted small"><?= sanitize($user['login']) ?></span></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="<?= APP_URL ?>/modules/auth/logout.php">
              <i class="bi bi-box-arrow-right me-1"></i>Déconnexion
            </a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</nav>

<div class="hc-content container-fluid px-4 py-3">
