
</div><!-- /.hc-content -->

<footer class="hc-footer text-center text-muted small py-2 mt-auto">
  <?= APP_ETABLISSEMENT ?> &bull; <?= APP_NAME ?> v<?= APP_VERSION ?> &bull; &copy; <?= date('Y') ?>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= APP_URL ?>/assets/js/hospiconnect.js"></script>
<script>
// Horloge temps réel
(function() {
  const el = document.getElementById('hc-clock');
  if (!el) return;
  function tick() {
    const now = new Date();
    el.textContent = now.toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit', second:'2-digit'});
  }
  tick(); setInterval(tick, 1000);
})();
</script>
</body>
</html>
