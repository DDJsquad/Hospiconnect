<?php
/**
 * HospiConnect - Fonctions utilitaires
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

// ─── Sécurité ────────────────────────────────────────────────────────────────

function generateCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken(string $token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function sanitize(string $val): string {
    return htmlspecialchars(trim($val), ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): void {
    header('Location: ' . $url);
    exit;
}

function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// ─── Session / Auth ──────────────────────────────────────────────────────────

function isLoggedIn(): bool {
    if (!isset($_SESSION['user_id'], $_SESSION['last_activity'])) return false;
    if (time() - $_SESSION['last_activity'] > SESSION_LIFETIME) {
        session_destroy();
        return false;
    }
    $_SESSION['last_activity'] = time();
    return true;
}

function requireAuth(array $roles = []): void {
    if (!isLoggedIn()) redirect(APP_URL . '/index.php');
    if (!empty($roles) && !in_array($_SESSION['role'], $roles)) {
        redirect(APP_URL . '/index.php?error=acces_refuse');
    }
}

function currentUser(): array {
    return [
        'id'          => $_SESSION['user_id']   ?? null,
        'login'       => $_SESSION['login']      ?? '',
        'role'        => $_SESSION['role']        ?? '',
        'nom_complet' => $_SESSION['nom_complet'] ?? '',
        'service_id'  => $_SESSION['service_id'] ?? null,
    ];
}

// ─── IPP Patient ─────────────────────────────────────────────────────────────

function generateIPP(): string {
    $db = getDB();
    do {
        $ipp = 'CDCh-' . date('Y') . '-' . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);
        $stmt = $db->prepare('SELECT id FROM patients WHERE ipp = ?');
        $stmt->execute([$ipp]);
    } while ($stmt->fetch());
    return $ipp;
}

// ─── Ticket ──────────────────────────────────────────────────────────────────

function generateTicketNumber(int $serviceId): string {
    $db = getDB();
    $stmt = $db->prepare('SELECT code_prefixe FROM services WHERE id = ?');
    $stmt->execute([$serviceId]);
    $service = $stmt->fetch();
    if (!$service) return 'TKT-000';

    $prefix = strtoupper($service['code_prefixe']);
    $today  = date('Y-m-d');

    $stmt = $db->prepare("
        SELECT COUNT(*) as total FROM tickets
        WHERE service_id = ? AND DATE(cree_le) = ?
    ");
    $stmt->execute([$serviceId, $today]);
    $count = $stmt->fetch()['total'] + 1;

    return $prefix . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);
}

// ─── Audit log ───────────────────────────────────────────────────────────────

function auditLog(string $action, ?int $entiteId = null, ?string $tableCible = null, array $details = []): void {
    try {
        $db = getDB();
        $stmt = $db->prepare("
            INSERT INTO audit_logs (user_id, action, table_cible, entite_id, details, ip_address)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $_SESSION['user_id'] ?? null,
            $action,
            $tableCible,
            $entiteId,
            empty($details) ? null : json_encode($details),
            $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    } catch (Exception $e) {
        // silencieux - ne pas bloquer l'appli si le log échoue
    }
}

// ─── Temps d'attente ─────────────────────────────────────────────────────────

function getWaitMinutes(string $creeLe): int {
    return (int) round((time() - strtotime($creeLe)) / 60);
}

function waitBadgeClass(int $minutes): string {
    if ($minutes >= WAIT_ALERT_MINUTES) return 'danger';
    if ($minutes >= 20) return 'warning';
    return 'success';
}

// ─── Priorité ────────────────────────────────────────────────────────────────

function priorityBadge(string $priorite): string {
    $map = [
        'urgence'     => '<span class="badge bg-danger"><i class="bi bi-exclamation-triangle-fill me-1"></i>Urgence</span>',
        'prioritaire' => '<span class="badge bg-warning text-dark"><i class="bi bi-arrow-up-circle-fill me-1"></i>Prioritaire</span>',
        'standard'    => '<span class="badge bg-success"><i class="bi bi-check-circle-fill me-1"></i>Standard</span>',
    ];
    return $map[$priorite] ?? '<span class="badge bg-secondary">Inconnu</span>';
}

// ─── Email (PHPMailer simplifié ou mail() natif) ──────────────────────────────

function sendEmail(string $to, string $subject, string $htmlBody, int $ticketId = 0, int $patientId = 0, string $type = 'autre'): bool {
    $db = getDB();
    $statut = 'echec';
    $tentatives = 0;

    for ($i = 1; $i <= EMAIL_MAX_RETRIES; $i++) {
        $tentatives = $i;
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: " . SMTP_FROM_NAME . " <" . SMTP_FROM . ">\r\n";

        if (@mail($to, $subject, $htmlBody, $headers)) {
            $statut = 'envoye';
            break;
        }
        if ($i < EMAIL_MAX_RETRIES) sleep($i * 2);
    }

    // Log email
    try {
        $stmt = $db->prepare("
            INSERT INTO email_logs (ticket_id, patient_id, type_email, destinataire, statut, tentatives)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$ticketId ?: null, $patientId ?: null, $type, $to, $statut, $tentatives]);
    } catch (Exception $e) {}

    return $statut === 'envoye';
}

function emailTemplateArrivee(string $nomPrenom, string $service, string $numero, string $heure, int $waitMin): string {
    return <<<HTML
<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
body{font-family:Arial,sans-serif;background:#f4f4f4;margin:0;padding:20px}
.card{background:#fff;border-radius:8px;max-width:600px;margin:auto;overflow:hidden}
.header{background:#1A3A5C;color:#fff;padding:24px;text-align:center}
.header h1{margin:0;font-size:22px}
.body{padding:28px}
.ticket{background:#e8f4fd;border-left:4px solid #2E75B6;padding:16px;border-radius:4px;margin:20px 0;text-align:center}
.ticket-num{font-size:32px;font-weight:bold;color:#1A3A5C;letter-spacing:2px}
.footer{background:#f9f9f9;padding:16px;text-align:center;font-size:12px;color:#888}
</style></head>
<body>
<div class="card">
  <div class="header">
    <h1>🏥 Clinique du Chatelet</h1>
    <p style="margin:4px 0 0;opacity:.8">Confirmation d'enregistrement</p>
  </div>
  <div class="body">
    <p>Bonjour <strong>$nomPrenom</strong>,</p>
    <p>Votre arrivée au service <strong>$service</strong> a bien été enregistrée à <strong>$heure</strong>.</p>
    <div class="ticket">
      <p style="margin:0 0 8px;color:#555">Votre numéro de ticket</p>
      <div class="ticket-num">$numero</div>
      <p style="margin:8px 0 0;color:#888;font-size:13px">Temps d'attente estimé : <strong>~$waitMin min</strong></p>
    </div>
    <p>Veuillez rester dans la salle d'attente. Votre numéro sera affiché sur l'écran dès votre tour.</p>
    <p>Merci de votre confiance.</p>
  </div>
  <div class="footer">Clinique du Chatelet &bull; Ce message est automatique, merci de ne pas y répondre.</div>
</div>
</body></html>
HTML;
}

function emailTemplateExamens(string $nomPrenom, string $dateExamen): string {
    return <<<HTML
<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
body{font-family:Arial,sans-serif;background:#f4f4f4;margin:0;padding:20px}
.card{background:#fff;border-radius:8px;max-width:600px;margin:auto;overflow:hidden}
.header{background:#1E7A1E;color:#fff;padding:24px;text-align:center}
.header h1{margin:0;font-size:22px}
.body{padding:28px}
.alert-box{background:#e8f9e8;border-left:4px solid #1E7A1E;padding:16px;border-radius:4px;margin:20px 0}
.footer{background:#f9f9f9;padding:16px;text-align:center;font-size:12px;color:#888}
</style></head>
<body>
<div class="card">
  <div class="header">
    <h1>✅ Clinique du Chatelet</h1>
    <p style="margin:4px 0 0;opacity:.8">Résultats d'examens disponibles</p>
  </div>
  <div class="body">
    <p>Bonjour <strong>$nomPrenom</strong>,</p>
    <div class="alert-box">
      <strong>Vos résultats d'examens réalisés le $dateExamen sont maintenant disponibles.</strong>
    </div>
    <p>Nous vous invitons à vous rapprocher de l'accueil de la clinique afin de récupérer vos documents.</p>
    <p><strong>Horaires d'accueil :</strong> Lundi – Vendredi, 07h30 – 18h00</p>
    <p>Merci de votre confiance.</p>
  </div>
  <div class="footer">Clinique du Chatelet &bull; Aucune donnée médicale n'est transmise par email pour des raisons de confidentialité.</div>
</div>
</body></html>
HTML;
}
