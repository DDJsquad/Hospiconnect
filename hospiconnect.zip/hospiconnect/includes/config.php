<?php
/**
 * HospiConnect - Clinique du Chatelet
 * Fichier de configuration central
 */

// ─── Base de données ────────────────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_NAME', 'hospiconnect');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// ─── Application ────────────────────────────────────────────────────────────
define('APP_NAME', 'HospiConnect');
define('APP_ETABLISSEMENT', 'Clinique du Chatelet');
define('APP_URL', 'http://localhost/hospiconnect');
define('APP_VERSION', '1.0');

// ─── Sécurité ────────────────────────────────────────────────────────────────
define('SESSION_LIFETIME', 1800);        // 30 minutes
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_DURATION', 900);         // 15 minutes en secondes

// ─── File d'attente ─────────────────────────────────────────────────────────
define('WAIT_ALERT_MINUTES', 45);        // Seuil alerte rouge
define('MAX_QUEUE_ALERT', 20);           // Seuil alerte file pleine
define('POLLING_INTERVAL', 15000);       // ms - rafraîchissement AJAX

// ─── Email SMTP ─────────────────────────────────────────────────────────────
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'votre.email@gmail.com');
define('SMTP_PASS', 'votre_mot_de_passe_app');
define('SMTP_FROM', 'noreply@clinique-chatelet.fr');
define('SMTP_FROM_NAME', 'Clinique du Chatelet');
define('EMAIL_MAX_RETRIES', 3);

// ─── Chemins ────────────────────────────────────────────────────────────────
define('ROOT_PATH', dirname(__DIR__));
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('ASSETS_PATH', ROOT_PATH . '/assets');

// ─── Timezone ───────────────────────────────────────────────────────────────
date_default_timezone_set('Europe/Paris');

// ─── Démarrage session sécurisé ─────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_strict_mode', 1);
    session_start();
}
